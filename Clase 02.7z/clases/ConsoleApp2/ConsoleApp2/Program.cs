﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            char continuar;
            do
            {

                Console.WriteLine("quiere continuar?");
                continuar = Convert.ToChar(Console.ReadKey());
            } while (continuar != 'n');
        }
    }
}
