using System;

namespace ConsoleApp1
{
  class Program
  {
    static void Main(string[] args)
    {
      string textoIgresado;
      int numero;
      int min=-100;
      int max=100;
      int suma=0;
      int promedio;
      int valorMaximo=int.MinValue;
      int valorMinimo=int.MaxValue;
      int contador = 0;

      Console.WriteLine("ingrese 10 numeros enteros de -100 a 100");
      do
      { 
        textoIgresado=Console.ReadLine();
        bool verificarQueEsNumero= Int32.TryParse(textoIgresado, out numero);
        if(verificarQueEsNumero)
        {
          if(Validacion.Validar(numero, min, max))
          {
            if(numero>valorMaximo)
            {
              valorMaximo = numero;
            }
            else if(numero<valorMinimo)
            {
              valorMinimo = numero;
            }
            suma = suma + numero;
            contador++;
          }
          else
          {
            Console.WriteLine("numero fuera de rango");
          }
        }
      } while (contador <= 10);
      promedio = suma / 10;
      Console.WriteLine("el promedio es {0} el valor maximo es {1}el valor minimo es {2}", promedio,valorMaximo,valorMinimo);

      Console.ReadKey();

    }
  }
}
