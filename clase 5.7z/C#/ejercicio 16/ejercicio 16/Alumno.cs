﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_16
{
    public class Alumno
    {

        Random objetoRamdom = new Random();

        public string name;
        public string lastName;
        public int legajo;

        private byte nota1;
        private byte nota2;
        private float notaFinal;

        public void Estudiar(byte nota1, byte nota2)
        {
            this.nota1 = nota1;
            this.nota2 = nota2;

        }
        public void CalcularFinal()
        {
            if (this.nota1 >= 4 && this.nota2 >= 4)
            {
                this.notaFinal = objetoRamdom.Next(10);
            }
            else
                this.notaFinal = -1;               
            
        }
        public void Mostrar()
        {
           Console.WriteLine("Name: {0}\nLastName: {1}\nLegajo{2}",this.name,this.lastName,this.legajo);
           Console.WriteLine("Nota 1: {0}\nNota 2: {1}",this.nota1,this.nota2);
            if (this.notaFinal != -1)
            {
                Console.WriteLine("Nota final: {0}\n", this.notaFinal);
            }
            else
                Console.WriteLine("Nota final: DESAPROBADO");
        }
    }
}
