﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_16
{
    class Program
    {
        static void Main(string[] args)
        {
            Alumno alumno1 = new Alumno();
            Alumno alumno2 = new Alumno();
            Alumno alumno3 = new Alumno();

            alumno1.name = "jonathan";
            alumno1.lastName = "Haedo";
            alumno1.legajo = 1;
            alumno1.Estudiar(5, 4);
            alumno1.CalcularFinal();

            alumno2.name = "Martin";
            alumno2.lastName = "Ramirez";
            alumno2.legajo = 2;
            alumno2.Estudiar(5, 9);
            alumno2.CalcularFinal();

            alumno3.name = "Luciana";
            alumno3.lastName = "Gonzales";
            alumno3.legajo = 3;
            alumno3.Estudiar(5, 1);
            alumno3.CalcularFinal();

            alumno1.Mostrar();
            alumno2.Mostrar();
            alumno3.Mostrar();

            Console.ReadKey();
        }
    }
}
