﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio14
{
    class Program
    {
        static void Main(string[] args)
        {
            double numero;
            string numeroString;
            numeroString = Console.ReadLine();
            bool esNumerico = double.TryParse(numeroString,out numero);
            if(esNumerico)
            {
                Console.WriteLine( CalculoDeArea.CalcularCirculo(numero));
            }
            Console.ReadKey();
        }
    }
}
