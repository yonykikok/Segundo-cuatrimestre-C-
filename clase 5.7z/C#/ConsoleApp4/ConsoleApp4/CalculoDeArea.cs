﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio14
{
    public class CalculoDeArea
    {
        public static double CalcularCuadrado(double numero)
        {
            double resultado;

            resultado = numero * numero;

            return resultado;
        }
        public static double CalcularTriangulo(double basee, double altura)
        {
            double resultado;

            resultado= basee*altura / 2;

            return resultado;
        }
        public static double CalcularCirculo(double circunferencia)
        {
            double resultado;
            double pi=3.14159;

            double radio = (circunferencia) / (pi*2);//circunferencia dividido 2 pi

            resultado = pi*Math.Pow(radio,2);

            return resultado;
        }
    }
}
