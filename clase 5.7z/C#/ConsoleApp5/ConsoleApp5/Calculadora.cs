﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio15
{
    class Calculadora
    {
        public static double Calcular(double numero, double numero2, char operador)
        {
            
            double resultado=0;
            switch (operador)
            {
                case '-':
                    resultado = numero - numero2;
                    break;
                case '+':
                    resultado = numero + numero2;
                    break;
                case '/':
                    if(Validar(numero2))
                    {
                      resultado = numero / numero2;
                    }
                    else
                    {
                        Console.WriteLine("no se puede dividir por numeros menores o igual a '0' ");
                    }
                    break;
                case '*':
                    resultado = numero * numero2;
                    break;
            }
            return resultado;
        }
        private static bool Validar(double numero2)
        {
            bool retorno = false;
            if (numero2 != 0 && numero2 > 0)
            {
                retorno = true;
            }
            return retorno;
        }
        public static void Mostrar (double resultado)
        {
            Console.WriteLine("el resultado es {0}", resultado);
        }
            
            

    }
}
