﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio15
{
    class Program
    {
        static void Main(string[] args)
        {
            double numero;
            double numero2;
            char operador;

            string numeroString=Console.ReadLine();
            //operador=Console.ReadKey().KeyChar;
            string operadorString = Console.ReadLine();
            string numero2String = Console.ReadLine();

            bool esOperador = char.TryParse(operadorString, out operador);
            bool esNumerico = double.TryParse(numeroString, out numero);
            bool esNumerico2 = double.TryParse(numero2String, out numero2);

            if((esNumerico==true) && (esNumerico2==true) && esOperador == true)
            {
                if ( (operador=='+') || (operador == '-') || (operador == '*') || (operador == '/') )
                {
                    Calculadora.Mostrar(Calculadora.Calcular(numero, numero2, operador));
                }
            }
            Console.ReadKey();



        }
    }
}
