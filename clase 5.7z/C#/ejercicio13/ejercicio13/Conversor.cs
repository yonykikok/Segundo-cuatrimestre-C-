﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio13
{
    class Conversor
    {
        public static string DecimalBinario(double doble)
        {
            int cociente;

            while(cociente != 1)
            {

            }
            return "asd";
        }

        public static double BinarioDecimal(string binario)
        {
            return 1;
        }
    }
}
