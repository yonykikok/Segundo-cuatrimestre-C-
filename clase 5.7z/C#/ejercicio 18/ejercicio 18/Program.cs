using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Geometria;

namespace PuebaGeometrica
{
  class Program
  {
    static void Main(string[] args)
    {
      Punto p1 = new Punto(2,1);
      Punto p3 = new Punto(1,2);
      Rectangulo rectangulo1 = new Rectangulo(p1,p3);
      Console.WriteLine("area: "+rectangulo1.GetArea());
      Console.WriteLine("perimetro: "+rectangulo1.GetPerimetro());
      Console.ReadKey();
      
    }
  }
}
