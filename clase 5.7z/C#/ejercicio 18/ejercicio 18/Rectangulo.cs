using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometria
{
  public class Rectangulo
  {
    private float area;
    private float perimetro;
    private Punto vertice1;
    private Punto vertice2;
    private Punto vertice3;
    private Punto vertice4;

    public Rectangulo(Punto inVertice1, Punto inVertice3)
    {
      this.vertice1 = inVertice1;
      this.vertice2 = new Punto(inVertice3.GetX(), inVertice1.GetY());
      this.vertice3 = inVertice3;
      this.vertice4 = new Punto(vertice1.GetX(), vertice3.GetY());
    }

    public float GetArea()
    {
      float calcularBase;
      float calcularAltura;

      if (this.area == 0)//solo entra la primera ves (valor por defecto float).
      {
        calcularBase = Math.Abs(vertice1.GetX() - vertice2.GetX());
        calcularAltura = Math.Abs(vertice1.GetX() - vertice4.GetY());
        this.area = calcularBase * calcularAltura;
      }
      return this.area;
    }
    public float GetPerimetro()
    {
      float calcularBase;
      float calcularAltura;

      if (this.perimetro==0)//solo entra la primera ves (valor por defecto float).
      {
        calcularBase = Math.Abs(vertice1.GetX() - vertice2.GetX());
        calcularAltura = Math.Abs(vertice1.GetX() - vertice4.GetY());
        this.perimetro = (calcularBase + calcularAltura) * 2;
      }
      return this.perimetro;
    }
  }
}
