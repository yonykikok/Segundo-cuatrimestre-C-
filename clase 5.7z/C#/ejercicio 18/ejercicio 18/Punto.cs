using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Geometria
{
  public class Punto
  {
    private int x;
    private int y;

    public int GetX()
    {
      return this.x;
    }
    public int GetY()
    {
      return this.y;
    }
    public Punto(int inX, int inY)
    {
      this.x = inX;
      this.y = inY;
    }
  }
}
