using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_17
{
    class Boligrafo
    {
        ConsoleColor color;
        short tinta;
        const int cantidadTintaMaxima = 100;

        public ConsoleColor GetColor()
        {
          return this.color;
        }
        public int GetTinta()
        {
          return this.tinta;
        }
        private void SetTinta(short tinta)
        {
            int cantidadTotal=0;
            if(tinta<0)
            {
              cantidadTotal = this.tinta - tinta;
              if(cantidadTotal>=0)
              {
                this.tinta-=tinta;
              }
            }
            else if (tinta >= 0)
            {
              cantidadTotal = this.tinta + tinta;
              if (cantidadTotal <= cantidadTintaMaxima)
              {
                this.tinta += tinta;
              }
            }
            
        }
        public void Recargar()
        {
          short tintaActual=this.tinta;    
          short tintaARecargar=(short)(100-tintaActual);
          SetTinta(tintaARecargar);
        }
         public void Constructor(short tinta, ConsoleColor color)
         {
          this.color = color;
          this.tinta = tinta;
         }
        public bool Pintar(int gasto, out string dibujo)
        {
          dibujo = "";
          int i;
          bool retorno=false;
          int tintaActual=this.GetTinta();
          int tintaARestar = gasto-(gasto*2);
          SetTinta((short)gasto);//seteo el valor
          if(tintaActual<this.tinta)//si se resto seteo "dibujo"
          {
            for(i=0;i<gasto;i++)
            {
              dibujo += "*";
            }
            retorno = true;
          }
          return retorno;                    
        }
    }
}
