using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_17
{
    class Program
    {
        static void Main(string[] args)
        {
          string dibujo;
          Boligrafo miBoligrafo = new Boligrafo();
          miBoligrafo.Constructor(100, ConsoleColor.Blue);

          Boligrafo miBoligrafo2 = new Boligrafo();
          miBoligrafo.Constructor(50, ConsoleColor.Red);

          if(miBoligrafo.Pintar(49,out dibujo)==true)
          {
            Console.WriteLine(dibujo);
          }
      Console.ReadKey();
        }
  }
}
