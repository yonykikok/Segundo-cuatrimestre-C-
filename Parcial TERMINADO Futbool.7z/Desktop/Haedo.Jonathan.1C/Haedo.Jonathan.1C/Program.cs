using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;
namespace Haedo.Jonathan._1C
{
    class Program
    {
        static void Main(string[] args)
        {
      DirectorTecnico directorTecnico = new DirectorTecnico("Martin", "Suarez");
      Equipo miEquipo = new Equipo("Boca Junior", directorTecnico);
      Jugador Jugador1 = new Jugador("juan", "perez", true, 1);
      Jugador Jugador2 = new Jugador("Jonathan", "Martinez", false, 2);
      Jugador Jugador3 = new Jugador("Miguel", "Huissi", false, 10);
      Jugador Jugador4 = new Jugador("Lucas", "Peralta", false, 5);

      miEquipo += Jugador1;
      miEquipo += Jugador2;
      miEquipo += Jugador3;
      miEquipo += Jugador4;
      Console.WriteLine(miEquipo);


      Console.ReadKey();
    }
    }
}
