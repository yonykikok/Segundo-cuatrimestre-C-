using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public class Jugador : Persona
    {
        private int numero;
        private bool esCapitan;

        public Jugador(string nombre, string apellido, bool esCapitan, int numero) :this(nombre, apellido)
        {
            this.esCapitan = esCapitan;
            this.numero = numero;
        }
        public Jugador(string nombre, string apellido) : base(nombre, apellido)
        {
            this.numero = 0;
            this.esCapitan = false;
        }

        public bool EsCapitan
        {
            get
            {
                return this.esCapitan;
            }
        }
        public int Numero
        {
            get
            {
                return this.numero;
            }
        }

        protected override string FichaTecnica()
        {
            StringBuilder retorno = new StringBuilder();
            retorno.Append(base.NombreCompleto());
            if (EsCapitan)
            {
                retorno.AppendFormat(", Capitán del equipo,", Numero);
            }
            retorno.AppendFormat(" Camiseta número: {0}", Numero);

        return retorno.ToString();
        }

        public static bool operator ==(Jugador jugadorUno, Jugador jugadorDos)
        {
            bool retorno = false;
            if ((jugadorUno.Nombre == jugadorDos.Nombre) && (jugadorUno.Apellido == jugadorDos.Apellido) && (jugadorUno.Numero == jugadorDos.Numero) )
            {
                retorno = true;
            }
            return retorno;

        }
        public static bool operator !=(Jugador jugadorUno, Jugador jugadorDos)
        {
            bool retorno = false;
            if (!(jugadorUno == jugadorDos))
            {
                retorno = true;
            }
            return retorno;
        }
        public static explicit operator int(Jugador jugador)
        {
            return jugador.Numero;
        }

        public override string ToString()
        {
            return this.FichaTecnica();
        }
    public override bool Equals(object obj)
    {
      bool retorno = false;
      if((Jugador)obj == this)
      {
        retorno = true;
      }
      return retorno;
    }
  }
}
