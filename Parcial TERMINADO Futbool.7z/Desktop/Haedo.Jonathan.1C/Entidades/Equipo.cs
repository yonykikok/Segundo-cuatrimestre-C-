using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class Equipo
  {
    public enum Deportes
    {
      Basquet,
      Futbol,
      Handball,
      Rugby
    }
    static Deportes deporte;
    private DirectorTecnico directorTecnico;
    private List<Jugador> jugadores;
    private string nombre;

    public Deportes Deporte
    {
      set
      {
        deporte = value;
      }
    }
    private Equipo()
    {
      this.jugadores = new List<Jugador>();
    }
    static Equipo()
    {
      deporte = Deportes.Futbol;
    }
    public Equipo(string nombre, DirectorTecnico directorTecnico):this()
    {
      this.nombre = nombre;
      this.directorTecnico = directorTecnico;
    }
    public Equipo(string nombre, DirectorTecnico directorTecnico, Deportes deporte) : this(nombre, directorTecnico)
    {
      Deporte = deporte;
    }    
    public static bool operator ==(Equipo equipo, Jugador jugador)
    {
      bool retorno = false;
      foreach (Jugador jugadorB in equipo.jugadores)
      {
        if (jugadorB == jugador)
        {
          retorno = true;
          break;
        }
      }
      return retorno;
    }
    public static bool operator !=(Equipo equipo, Jugador jugador)
    {
      bool retorno = false;
      if (!(equipo == jugador))
      {
        retorno = true;
      }
      return retorno;
    }
    public static Equipo operator +(Equipo equipo, Jugador jugador)
    {
      if (equipo != jugador)
      {
        equipo.jugadores.Add(jugador);
      }
      return equipo;
    }

    public static Equipo operator -(Equipo equipo, Jugador jugador)
    {
      if (equipo == jugador)
      {
        equipo.jugadores.Remove(jugador);
      }
      return equipo;
    }
    public static implicit operator string(Equipo equipo)
    {
      StringBuilder retorno = new StringBuilder();
      retorno.AppendFormat("**{0} {1}**\n",equipo.nombre,deporte);
      retorno.AppendLine("Nomina de jugadores: ");
      foreach(Jugador jugador in equipo.jugadores)
      {
        retorno.AppendLine(jugador.ToString());
      }
      retorno.AppendFormat("Dirigido por: {0}", equipo.directorTecnico.ToString());

      return retorno.ToString();  
    }
    public override bool Equals(object obj)
    {
      bool retorno = false;
      if(obj is Jugador)
      {
        if(obj == this)
        {
          retorno = true;
        }
      }
      return retorno;
    }
  }
}
