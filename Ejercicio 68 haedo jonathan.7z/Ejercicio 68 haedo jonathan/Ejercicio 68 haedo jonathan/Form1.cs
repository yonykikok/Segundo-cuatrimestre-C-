﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
namespace Ejercicio_68_haedo_jonathan
{
    public partial class Form1 : Form
    {
        private Persona persona;
        private event DelegadoString evento;
        public static string NotificarCambio(string msg)
        {
            MessageBox.Show(msg);
            return msg;
        }
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.evento += NotificarCambio;
        }

        private void EventHover(object sender, EventArgs e)
        {

        }

        private void buttonCrear_Click(object sender, EventArgs e)
        {
            if (this.persona is null)
            {
                this.persona = new Persona(textBoxNombre.Text, textBoxApellido.Text);
                this.evento(persona.Mostrar() + " Creado Con Exito");

            }
            else
            {
                buttonCrear.Text = "Actualizar";
                if ((this.persona.Nombre == textBoxNombre.Text) && (this.persona.Apellido == textBoxApellido.Text))
                {
                    this.evento(persona.Mostrar() + " ya esta creada");
                }
                else
                {
                    this.evento(this.persona.Mostrar()+" se actualizo por "+textBoxNombre.Text+" "+ textBoxApellido.Text);
                    this.persona.Nombre = textBoxNombre.Text;
                    this.persona.Apellido = textBoxApellido.Text;
                }

            }
        }
    }
}
