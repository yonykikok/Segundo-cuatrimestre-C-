﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Entidades
{
    public delegate string DelegadoString(string msg);
}
