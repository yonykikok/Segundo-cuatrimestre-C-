﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;


namespace entidades
{
    public class Torneo<T> where T : Equipo
    {
        public string nombre;
        private List<T> equipos;

        private Torneo()
        {
            this.equipos = new List<T>();
        }
        public Torneo(string equipo):this()
        {
            this.nombre = equipo;
        }

        public static bool operator ==(Torneo<T> torneo, Equipo equipo)
        {
            bool retorno = false;
            foreach (Equipo auxEquipo in torneo.equipos)
            {
                if (auxEquipo == equipo)
                {
                    retorno = true;
                }
            }
            return retorno;
        }
        public static bool operator !=(Torneo<T> torneo, Equipo equipo)
        {
            bool retorno = false;
            if (!(torneo == equipo))
            {
                retorno = true;
            }
            return retorno;
        }
        public static Torneo<T> operator +(Torneo<T> torneo, Equipo equipo)
        {
            if (torneo != equipo)
            {
                torneo.equipos.Add((T)equipo);
            }
            return torneo;
        }

        public virtual string Mostrar()
        {
            StringBuilder retono = new StringBuilder();
            retono.AppendLine("Torneo: " + this.nombre);
            foreach (Equipo equipo in this.equipos)
            {
                retono.AppendLine(equipo.Ficha());
            }
            return retono.ToString();
        }
        private string CalcularPartido(T equipoUno, T equipoDos)
        {
            StringBuilder retorno = new StringBuilder();
            Random randomUno = new Random();

            int resultadoUno = randomUno.Next(1, 12);
            Thread.Sleep(1000);
            Random randomDos = new Random();
            int resultadoDos = randomDos.Next(1, 12);

            retorno.AppendLine(equipoUno.nombre + resultadoUno + " – " + resultadoDos + equipoDos.nombre);

            return retorno.ToString();
        }
        public string JugarPartido
        {
            get
            {
                Random randomUno = new Random();
                Random randomDos = new Random();
                int equipoUno = randomUno.Next(0 , this.equipos.Count);
                int equipoDos = randomUno.Next(0 , this.equipos.Count);
                                
                return CalcularPartido(this.equipos[equipoUno], this.equipos[equipoDos]);
            }
        }
    }
}
