﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace entidades
{
    public abstract class Equipo
    {
        public string nombre;
        public DateTime fechaCreacion;

        public Equipo(string nombre, DateTime frechaDeCreacion)
        {
            this.nombre = nombre;
            this.fechaCreacion = frechaDeCreacion;
        }
        public string Ficha()
        {
            StringBuilder retorno = new StringBuilder();
            retorno.AppendLine(this.nombre+"fundado el "+this.fechaCreacion);
            return retorno.ToString();
        }
        public static bool operator ==(Equipo equipoUno, Equipo equipoDos)
        {
            bool retorno = false;
            if (equipoUno.nombre == equipoDos.nombre && equipoUno.fechaCreacion == equipoDos.fechaCreacion)
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Equipo equipoUno, Equipo equipoDos)
        {
            bool retorno = false;
            if (! (equipoUno == equipoDos))
            {
                retorno = true;
            }
            return retorno;
        }

    }
}
