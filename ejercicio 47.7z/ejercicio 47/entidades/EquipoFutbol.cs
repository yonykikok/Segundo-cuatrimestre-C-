﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace entidades
{
    public class EquipoFutbol:Equipo
    {
        public EquipoFutbol(string nombre, DateTime frechaDeCreacion) : base(nombre, frechaDeCreacion)
        {

        }
    }
}
