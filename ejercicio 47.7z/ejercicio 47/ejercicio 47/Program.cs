﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using entidades;
namespace ejercicio_47
{
    class Program
    {
        static void Main(string[] args)
        {
            //instancio 2 torneos
            Torneo<EquipoBasquet> basquet = new Torneo<EquipoBasquet>("Nacional");
            Torneo<EquipoFutbol> futbool = new Torneo<EquipoFutbol>("Internacional");
            //instancio 3 equipos de basquet
            EquipoBasquet equipoUnoBasquet = new EquipoBasquet("Tigres", new DateTime(1993, 06, 25));
            EquipoBasquet equipoDosBasquet = new EquipoBasquet("Masters", new DateTime(1995, 09, 21));
            EquipoBasquet equipoTresBasquet = new EquipoBasquet("Montes", new DateTime(1983, 08, 25));
            //instancio 3 equipos de futbool
            EquipoFutbol equipoUnoFutbool = new EquipoFutbol("Boca", new DateTime(2005, 06, 25));
            EquipoFutbol equipoDosFutbool = new EquipoFutbol("River", new DateTime(2001, 06, 25));
            EquipoFutbol equipoTresFutbool = new EquipoFutbol("Independiente", new DateTime(2016, 06, 25));
            //agrego equipos de basquet
            basquet += equipoUnoBasquet;
            basquet += equipoDosBasquet;
            basquet += equipoTresBasquet;
            //agrego equipos de futbool
            futbool += equipoUnoFutbool;
            futbool += equipoDosFutbool;
            futbool += equipoTresFutbool;


            Console.WriteLine("-----------------BASQUET----------------");
            Console.WriteLine(basquet.Mostrar());
            Console.WriteLine("-----------------FUTBOOL----------------");
            Console.WriteLine(futbool.Mostrar());


            Console.WriteLine("PARTIDOS JUGAGOS");
            Console.WriteLine(futbool.JugarPartido);
            Console.WriteLine(futbool.JugarPartido);
            Console.WriteLine(basquet.JugarPartido);
            Console.WriteLine(basquet.JugarPartido);
            Console.ReadKey();
        }
    }
}
