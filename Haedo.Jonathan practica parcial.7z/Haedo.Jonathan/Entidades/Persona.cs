﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Persona
    {
        private string nombre;
        private string documento;
        private string apellido;

        public string Apellido
        {
            get
            {
                return this.apellido;
            }
        }
        public string Nombre
        {
            get
            {
                return this.apellido;
            }
        }
        public string Documento
        {
            get
            {
                return this.apellido;
            }
            set
            {
                if (ValidarDocumentacion(value))
                {
                    this.documento = value;
                }
            }
        }
        public virtual string ExponerDatos()
        {
            StringBuilder retorno = new StringBuilder();
            retorno.Append("Nombre: ");
            retorno.AppendLine(this.nombre);
            retorno.Append("Apellido: ");
            retorno.AppendLine(this.apellido);
            retorno.Append("Documento: ");
            retorno.AppendLine(this.documento);

            return retorno.ToString();
        }
        public Persona(string nombre, string apellido, string documento)
        {
            Documento = documento;
            this.nombre = nombre;
            this.apellido = apellido;

        }
        protected abstract bool ValidarDocumentacion(string doc);

    }
}
