﻿namespace VistaForm
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.textBoxNameAlumno = new System.Windows.Forms.TextBox();
            this.textBoxLastNameAlumno = new System.Windows.Forms.TextBox();
            this.textBoxLegajo = new System.Windows.Forms.TextBox();
            this.comboBoxDivisionAlumno = new System.Windows.Forms.ComboBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxDni = new System.Windows.Forms.TextBox();
            this.textBoxLastNameDatos = new System.Windows.Forms.TextBox();
            this.textBoxNameDatos = new System.Windows.Forms.TextBox();
            this.comboBoxDivisionDatos = new System.Windows.Forms.ComboBox();
            this.numericUpDownDatos = new System.Windows.Forms.NumericUpDown();
            this.numericUpDownAlumno = new System.Windows.Forms.NumericUpDown();
            this.buttonCrearCurso = new System.Windows.Forms.Button();
            this.buttonMostrar = new System.Windows.Forms.Button();
            this.buttonAgregar = new System.Windows.Forms.Button();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.richTextBox = new System.Windows.Forms.RichTextBox();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDatos)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAlumno)).BeginInit();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.dateTimePicker);
            this.groupBox1.Controls.Add(this.buttonMostrar);
            this.groupBox1.Controls.Add(this.buttonCrearCurso);
            this.groupBox1.Controls.Add(this.numericUpDownDatos);
            this.groupBox1.Controls.Add(this.comboBoxDivisionDatos);
            this.groupBox1.Controls.Add(this.textBoxNameDatos);
            this.groupBox1.Controls.Add(this.textBoxLastNameDatos);
            this.groupBox1.Controls.Add(this.textBoxDni);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Location = new System.Drawing.Point(12, 25);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(372, 234);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Datos Curso";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label11);
            this.groupBox2.Controls.Add(this.label10);
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.label8);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.buttonAgregar);
            this.groupBox2.Controls.Add(this.numericUpDownAlumno);
            this.groupBox2.Controls.Add(this.comboBoxDivisionAlumno);
            this.groupBox2.Controls.Add(this.textBoxLegajo);
            this.groupBox2.Controls.Add(this.textBoxLastNameAlumno);
            this.groupBox2.Controls.Add(this.textBoxNameAlumno);
            this.groupBox2.Location = new System.Drawing.Point(401, 25);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(375, 234);
            this.groupBox2.TabIndex = 1;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Datos Alumno";
            // 
            // textBoxNameAlumno
            // 
            this.textBoxNameAlumno.Location = new System.Drawing.Point(166, 37);
            this.textBoxNameAlumno.Name = "textBoxNameAlumno";
            this.textBoxNameAlumno.Size = new System.Drawing.Size(184, 20);
            this.textBoxNameAlumno.TabIndex = 0;
            // 
            // textBoxLastNameAlumno
            // 
            this.textBoxLastNameAlumno.Location = new System.Drawing.Point(166, 63);
            this.textBoxLastNameAlumno.Name = "textBoxLastNameAlumno";
            this.textBoxLastNameAlumno.Size = new System.Drawing.Size(184, 20);
            this.textBoxLastNameAlumno.TabIndex = 1;
            // 
            // textBoxLegajo
            // 
            this.textBoxLegajo.Location = new System.Drawing.Point(166, 89);
            this.textBoxLegajo.Name = "textBoxLegajo";
            this.textBoxLegajo.Size = new System.Drawing.Size(184, 20);
            this.textBoxLegajo.TabIndex = 2;
            // 
            // comboBoxDivisionAlumno
            // 
            this.comboBoxDivisionAlumno.FormattingEnabled = true;
            this.comboBoxDivisionAlumno.Location = new System.Drawing.Point(166, 141);
            this.comboBoxDivisionAlumno.Name = "comboBoxDivisionAlumno";
            this.comboBoxDivisionAlumno.Size = new System.Drawing.Size(139, 21);
            this.comboBoxDivisionAlumno.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(15, 37);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(26, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Año";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(15, 63);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(44, 13);
            this.label2.TabIndex = 5;
            this.label2.Text = "Division";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(15, 89);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(44, 13);
            this.label3.TabIndex = 6;
            this.label3.Text = "Nombre";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(15, 115);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(44, 13);
            this.label4.TabIndex = 7;
            this.label4.Text = "Apellido";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(15, 141);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(26, 13);
            this.label5.TabIndex = 8;
            this.label5.Text = "DNI";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(15, 163);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(42, 13);
            this.label6.TabIndex = 9;
            this.label6.Text = "Ingreso";
            // 
            // textBoxDni
            // 
            this.textBoxDni.Location = new System.Drawing.Point(105, 134);
            this.textBoxDni.Name = "textBoxDni";
            this.textBoxDni.Size = new System.Drawing.Size(184, 20);
            this.textBoxDni.TabIndex = 4;
            // 
            // textBoxLastNameDatos
            // 
            this.textBoxLastNameDatos.Location = new System.Drawing.Point(105, 108);
            this.textBoxLastNameDatos.Name = "textBoxLastNameDatos";
            this.textBoxLastNameDatos.Size = new System.Drawing.Size(184, 20);
            this.textBoxLastNameDatos.TabIndex = 10;
            // 
            // textBoxNameDatos
            // 
            this.textBoxNameDatos.Location = new System.Drawing.Point(105, 82);
            this.textBoxNameDatos.Name = "textBoxNameDatos";
            this.textBoxNameDatos.Size = new System.Drawing.Size(184, 20);
            this.textBoxNameDatos.TabIndex = 11;
            // 
            // comboBoxDivisionDatos
            // 
            this.comboBoxDivisionDatos.FormattingEnabled = true;
            this.comboBoxDivisionDatos.Location = new System.Drawing.Point(105, 55);
            this.comboBoxDivisionDatos.Name = "comboBoxDivisionDatos";
            this.comboBoxDivisionDatos.Size = new System.Drawing.Size(139, 21);
            this.comboBoxDivisionDatos.TabIndex = 4;
            // 
            // numericUpDownDatos
            // 
            this.numericUpDownDatos.Location = new System.Drawing.Point(105, 30);
            this.numericUpDownDatos.Name = "numericUpDownDatos";
            this.numericUpDownDatos.Size = new System.Drawing.Size(139, 20);
            this.numericUpDownDatos.TabIndex = 12;
            // 
            // numericUpDownAlumno
            // 
            this.numericUpDownAlumno.Location = new System.Drawing.Point(166, 115);
            this.numericUpDownAlumno.Name = "numericUpDownAlumno";
            this.numericUpDownAlumno.Size = new System.Drawing.Size(139, 20);
            this.numericUpDownAlumno.TabIndex = 13;
            // 
            // buttonCrearCurso
            // 
            this.buttonCrearCurso.Location = new System.Drawing.Point(6, 194);
            this.buttonCrearCurso.Name = "buttonCrearCurso";
            this.buttonCrearCurso.Size = new System.Drawing.Size(115, 34);
            this.buttonCrearCurso.TabIndex = 13;
            this.buttonCrearCurso.Text = "Crear Curso";
            this.buttonCrearCurso.UseVisualStyleBackColor = true;
            this.buttonCrearCurso.Click += new System.EventHandler(this.buttonCrearCurso_Click);
            // 
            // buttonMostrar
            // 
            this.buttonMostrar.Location = new System.Drawing.Point(251, 194);
            this.buttonMostrar.Name = "buttonMostrar";
            this.buttonMostrar.Size = new System.Drawing.Size(115, 34);
            this.buttonMostrar.TabIndex = 14;
            this.buttonMostrar.Text = "Mostrar";
            this.buttonMostrar.UseVisualStyleBackColor = true;
            this.buttonMostrar.Click += new System.EventHandler(this.buttonMostrar_Click);
            // 
            // buttonAgregar
            // 
            this.buttonAgregar.Location = new System.Drawing.Point(238, 182);
            this.buttonAgregar.Name = "buttonAgregar";
            this.buttonAgregar.Size = new System.Drawing.Size(131, 46);
            this.buttonAgregar.TabIndex = 15;
            this.buttonAgregar.Text = "Agregar";
            this.buttonAgregar.UseVisualStyleBackColor = true;
            this.buttonAgregar.Click += new System.EventHandler(this.buttonAgregar_Click);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(17, 40);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(44, 13);
            this.label7.TabIndex = 15;
            this.label7.Text = "Nombre";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(17, 66);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(44, 13);
            this.label8.TabIndex = 15;
            this.label8.Text = "Apellido";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(17, 144);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(44, 13);
            this.label9.TabIndex = 15;
            this.label9.Text = "Division";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(17, 117);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(26, 13);
            this.label10.TabIndex = 15;
            this.label10.Text = "Año";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(17, 92);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(39, 13);
            this.label11.TabIndex = 16;
            this.label11.Text = "Legajo";
            // 
            // richTextBox
            // 
            this.richTextBox.Location = new System.Drawing.Point(12, 265);
            this.richTextBox.Name = "richTextBox";
            this.richTextBox.Size = new System.Drawing.Size(764, 173);
            this.richTextBox.TabIndex = 17;
            this.richTextBox.Text = "";
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Location = new System.Drawing.Point(105, 160);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker.TabIndex = 15;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.richTextBox);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Vista Del Curso";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownDatos)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDownAlumno)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Button buttonMostrar;
        private System.Windows.Forms.Button buttonCrearCurso;
        private System.Windows.Forms.NumericUpDown numericUpDownDatos;
        private System.Windows.Forms.ComboBox comboBoxDivisionDatos;
        private System.Windows.Forms.TextBox textBoxNameDatos;
        private System.Windows.Forms.TextBox textBoxLastNameDatos;
        private System.Windows.Forms.TextBox textBoxDni;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button buttonAgregar;
        private System.Windows.Forms.NumericUpDown numericUpDownAlumno;
        private System.Windows.Forms.ComboBox comboBoxDivisionAlumno;
        private System.Windows.Forms.TextBox textBoxLegajo;
        private System.Windows.Forms.TextBox textBoxLastNameAlumno;
        private System.Windows.Forms.TextBox textBoxNameAlumno;
        private System.Windows.Forms.RichTextBox richTextBox;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
    }
}

