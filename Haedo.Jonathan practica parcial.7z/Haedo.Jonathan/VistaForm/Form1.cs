﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
namespace VistaForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCrearCurso_Click(object sender, EventArgs e)
        {
            MessageBox.Show("ERROR.", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            short anio = (short)numericUpDownDatos.Value;
            Divisiones division;
            string name = textBoxLastNameDatos.Text.ToString();
            string lastName = textBoxLastNameDatos.Text.ToString();
            string dni = textBoxDni.Text.ToString();
            
            Enum.TryParse<Divisiones>(comboBoxDivisionDatos.SelectedValue.ToString(), out division);
            Profesor profesor = new Profesor(name, lastName, dni);  
           
            Curso miCurso = new Curso(anio, division, profesor);
            if(miCurso is null)
            {
                MessageBox.Show("ERROR.", "", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }           

        }

        private void buttonAgregar_Click(object sender, EventArgs e)
        {
            string name = textBoxNameAlumno.Text.ToString(); ;
            string lastName=textBoxLastNameAlumno.Text.ToString();
            string dni=textBoxDni.Text.ToString();
            Divisiones division;
            Enum.TryParse<Divisiones>(comboBoxDivisionAlumno.SelectedValue.ToString(), out division);
            short anio=(short)numericUpDownAlumno.Value;
            
            Alumno alumno = new Alumno(name,lastName,dni,anio,division);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            comboBoxDivisionDatos.DataSource = Enum.GetValues(typeof(Divisiones));
            comboBoxDivisionAlumno.DataSource = Enum.GetValues(typeof(Divisiones));
        }

        private void buttonMostrar_Click(object sender, EventArgs e)
        {

            //richTextBox.AppendText((string)miCurso);
        }
    }
}
