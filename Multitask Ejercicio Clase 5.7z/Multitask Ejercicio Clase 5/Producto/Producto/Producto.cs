using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Producto
{
  class Producto
  {
    protected string codigoDeBarra;
    protected string marca;
    protected float precio;

    //ctor tab tab Crea el contructor.
    public Producto(string inCodigoDeBarra, string inMarca, float inPrecio)
    {
      this.codigoDeBarra = inCodigoDeBarra;
      this.marca = inMarca;
      this.precio = inPrecio;
    }

    public string GetMarca()
    {
      return this.marca;
    }
    public float GetPrecio()
    {
      return this.precio;
    }
    public static explicit operator string(Producto inProducto)
    {
      string retorno;

      retorno = inProducto.codigoDeBarra;

      return retorno;
    }
    public static string MostrarProducto(Producto inProducto)
    {
      return "Marca " + inProducto.marca + "\nProducto " + inProducto.codigoDeBarra + "\nPrecio " + inProducto.precio+"\n";
    }

    public static bool operator == (Producto inProducto1, Producto inProducto2)
    {
      bool retorno=false;

      if(inProducto1.marca==inProducto2.marca && inProducto1.codigoDeBarra==inProducto2.codigoDeBarra)
      {
        retorno = true;
      }
      return retorno;      
    }
    public static bool operator !=(Producto inProducto1, Producto inProducto2)
    {
      bool retorno = false;

      if ( !(inProducto1==inProducto2) )
      {
        retorno = true;
      }
      return retorno;
    }

        public static bool operator ==(Producto inProducto, string inString)
        {
            bool retorno = false;
            if(inString==(string)inProducto.marca)
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Producto inProducto, string inString)
        {
            bool retorno = false;// creo un retorno y lo inicializo en false
            if ( !(inProducto==inString) )
            {
                retorno = true;
            }
            return retorno;
        }

    }
}
