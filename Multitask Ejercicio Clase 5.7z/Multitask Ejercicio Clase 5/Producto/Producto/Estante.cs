﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Producto
{
    class Estante
    {
        private Producto[] productos;
        private int ubicacionEstante;

        private Estante(int capacidad)
        {
            this.productos = new Producto[capacidad];
        }
        public Estante(int capacidad,int inUbicacion):this(capacidad)
        {
            this.ubicacionEstante = inUbicacion;
        }

        public Producto[] GetProducto()
        {
            return this.productos;
        }

        public string MostrarEstante(Estante inEstante)
        {
            StringBuilder stringBuilder = new StringBuilder();
            int i;

            for(i=0;i<inEstante.productos.Length;i++)
            {
                if(!(inEstante.productos[i] is null))
                {
                stringBuilder.AppendFormat("Producto:{0}\nUbicacion: {1}\n",this.productos[i],this.ubicacionEstante);
                stringBuilder.AppendLine(Producto.MostrarProducto(this.productos[i]));
                }
            }
            return stringBuilder.ToString();
        }
        public static bool operator ==(Estante inEstante, Producto inProducto)
        {
            bool retorno = false;
            int i=0;
            foreach (Producto producto in inEstante.productos)
            {

            }
            for(i=0;i<inEstante.productos.Length;i++)
            {

            }
            if(inEstante.productos[i].GetMarca() == inProducto.GetMarca())
            {

            }
            return retorno;
        }
        public static bool operator !=(Estante inEstante, Producto inProducto)
        {
            bool retorno = false;
            return retorno;

        }




    }
}
