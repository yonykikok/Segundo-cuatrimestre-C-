using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Producto
{
    class Program
    {
        static void Main(string[] args)
        {
            Producto monitorSamsung = new Producto("sam-42pF1080hd", "Samsung", (float)54.2);
            Estante estante = new Estante(5, 1);
            string marca = "Samsung";
            if (monitorSamsung == marca)
            {
                Console.WriteLine("operador de igualdad TEST. ( {0} )", marca);
            }
            Console.WriteLine(estante.MostrarEstante(estante));
            Console.ReadKey();
        }
    }
}
