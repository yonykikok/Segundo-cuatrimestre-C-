﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace Threads_HaedoJonathan
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = DateTime.Now.ToString();
            Thread t = new Thread(AsignarHora);
            t.Start();
        }

        private void Form1_Shown(object sender, EventArgs e)
        {

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void AsignarHora()
        {
            while (true)
            {
                Thread.Sleep(1000);
                if (this.label1.InvokeRequired)
                {
                    this.label1.BeginInvoke((MethodInvoker)delegate ()
                    {
                        label1.Text = DateTime.Now.ToString();
                        label1.Refresh();
                    }
                    );
                }
                else
                {
                    label1.Text = DateTime.Now.ToString();
                    label1.Refresh();

                }
            }
        }

        private void buttonStop_Click(object sender, EventArgs e)
        {

        }


    }
}
