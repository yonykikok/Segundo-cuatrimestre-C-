﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using Entidades;

namespace Haedo_Jonathan_ejercicio_064
{
    class Program
    {
        static void Main(string[] args)
        {
            Caja caja1 = new Caja();
            Caja caja2 = new Caja();
            Negocio negocio = new Negocio(caja1, caja2);
            negocio.Clientes.Add("Juan");
            negocio.Clientes.Add("Martin");
            negocio.Clientes.Add("Lucia");
            negocio.Clientes.Add("Martina");
            negocio.Clientes.Add("Rodrigo");
            negocio.Clientes.Add("Agustin");
            negocio.Clientes.Add("Laura");
            Thread t = new Thread(negocio.AsignarCaja);
            Thread t2 = new Thread(caja1.AtenderCliente);
            Thread t3 = new Thread(caja2.AtenderCliente);
            t2.Name = "Caja1";
            t3.Name = "Caja2";
            t.Start();
            t.Join();
            t2.Start();
            Thread.Sleep(750);
            t3.Start();            
            Console.ReadKey();
        }
    }
}
