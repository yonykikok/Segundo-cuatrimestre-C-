﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Entidades
{
    public class Negocio
    {
        Caja caja1;
        Caja caja2;
        List<string> clientes;

        public Negocio(Caja caja1, Caja caja2)
        {
            this.caja1 = caja1;
            this.caja2 = caja2;
            this.clientes = new List<string>();
        }

        public Caja Caja1
        {
            get
            {
                return this.caja1;
            }
        }
        public Caja Caja2
        {
            get
            {
                return this.caja2;
            }
        }
        public List<string> Clientes
        {
            get
            {
                return this.clientes;
            }
        }
        public void AsignarCaja()
        {
            Random random = new Random();
            int cajaRandom = random.Next(1, 2); ;
            Console.WriteLine("Asignando cajas...");

            for (int i = 0; i < this.clientes.Count; i++)
                {
                if (this.Caja1.FilaClientes.Count < this.Caja2.FilaClientes.Count)
                {
                    this.caja1.FilaClientes.Add(this.clientes[i] += " Caja1");
                }
                else if (this.Caja1.FilaClientes.Count > this.Caja2.FilaClientes.Count)
                {
                    this.caja2.FilaClientes.Add(this.clientes[i] += " Caja2");
                }
                else
                {
                    if (cajaRandom == 1)
                    {
                        this.caja1.FilaClientes.Add(this.clientes[i] += " Caja1");
                    }
                    else
                    {
                        this.caja2.FilaClientes.Add(this.clientes[i] += " Caja2");
                    }

                }
                Thread.Sleep(200);
            }
        }
    }
}
