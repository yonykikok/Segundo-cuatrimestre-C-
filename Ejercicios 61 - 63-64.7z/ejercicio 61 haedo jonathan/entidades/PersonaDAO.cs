﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace entidades
{
    public class PersonaDAO
    {
        private SqlConnection conexion;
        public PersonaDAO()
        {
            this.conexion = new SqlConnection("Data Source=.\\SQLEXPRESS;Initial Catalog=Persona;Integrated Security=True");
        }
        public int Guardar(Persona persona)
        {
            conexion.Open();
            SqlCommand comando = new SqlCommand("insert into Persona(Apellido,Nombre) values('" + persona.Apellido + "','" + persona.Nombre + "')", conexion);
            comando.ExecuteNonQuery();
            conexion.Close();
            return 1;
        }
        public int Modificar(Persona persona, int id)
        {          
            conexion.Open();
            string cmd = string.Format("UPDATE Persona SET Nombre = '{0}', Apellido ='{1}' WHERE id = {2}",persona.Nombre,persona.Apellido,id);
            SqlCommand comando = new SqlCommand(cmd,conexion);
            comando.ExecuteNonQuery();
            conexion.Close();
            return 1;
        }

    }
}
