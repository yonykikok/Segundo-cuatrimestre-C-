﻿namespace FormMenu
{
    partial class Central
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonGenerarLlamada = new System.Windows.Forms.Button();
            this.buttonFacturacionTotal = new System.Windows.Forms.Button();
            this.buttonFacturacionLocal = new System.Windows.Forms.Button();
            this.buttonFacturacionProvincial = new System.Windows.Forms.Button();
            this.buttonSalir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonGenerarLlamada
            // 
            this.buttonGenerarLlamada.Location = new System.Drawing.Point(30, 21);
            this.buttonGenerarLlamada.Name = "buttonGenerarLlamada";
            this.buttonGenerarLlamada.Size = new System.Drawing.Size(341, 92);
            this.buttonGenerarLlamada.TabIndex = 1;
            this.buttonGenerarLlamada.Text = "Generar Llamada";
            this.buttonGenerarLlamada.UseVisualStyleBackColor = true;
            this.buttonGenerarLlamada.Click += new System.EventHandler(this.button1_Click);
            // 
            // buttonFacturacionTotal
            // 
            this.buttonFacturacionTotal.Location = new System.Drawing.Point(30, 119);
            this.buttonFacturacionTotal.Name = "buttonFacturacionTotal";
            this.buttonFacturacionTotal.Size = new System.Drawing.Size(341, 92);
            this.buttonFacturacionTotal.TabIndex = 2;
            this.buttonFacturacionTotal.Text = "Facturacion Total";
            this.buttonFacturacionTotal.UseVisualStyleBackColor = true;
            this.buttonFacturacionTotal.Click += new System.EventHandler(this.button2_Click);
            // 
            // buttonFacturacionLocal
            // 
            this.buttonFacturacionLocal.Location = new System.Drawing.Point(30, 217);
            this.buttonFacturacionLocal.Name = "buttonFacturacionLocal";
            this.buttonFacturacionLocal.Size = new System.Drawing.Size(341, 92);
            this.buttonFacturacionLocal.TabIndex = 3;
            this.buttonFacturacionLocal.Text = "Facturacion Local";
            this.buttonFacturacionLocal.UseVisualStyleBackColor = true;
            this.buttonFacturacionLocal.Click += new System.EventHandler(this.buttonFacturacionLocal_Click);
            // 
            // buttonFacturacionProvincial
            // 
            this.buttonFacturacionProvincial.Location = new System.Drawing.Point(30, 315);
            this.buttonFacturacionProvincial.Name = "buttonFacturacionProvincial";
            this.buttonFacturacionProvincial.Size = new System.Drawing.Size(341, 92);
            this.buttonFacturacionProvincial.TabIndex = 6;
            this.buttonFacturacionProvincial.Text = "Facturacion Provincial";
            this.buttonFacturacionProvincial.UseVisualStyleBackColor = true;
            this.buttonFacturacionProvincial.Click += new System.EventHandler(this.buttonFacturacionProvincial_Click);
            // 
            // buttonSalir
            // 
            this.buttonSalir.Location = new System.Drawing.Point(30, 413);
            this.buttonSalir.Name = "buttonSalir";
            this.buttonSalir.Size = new System.Drawing.Size(341, 92);
            this.buttonSalir.TabIndex = 7;
            this.buttonSalir.Text = "Salir";
            this.buttonSalir.UseVisualStyleBackColor = true;
            this.buttonSalir.Click += new System.EventHandler(this.buttonSalir_Click);
            // 
            // Central
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(405, 518);
            this.Controls.Add(this.buttonSalir);
            this.Controls.Add(this.buttonFacturacionProvincial);
            this.Controls.Add(this.buttonFacturacionLocal);
            this.Controls.Add(this.buttonFacturacionTotal);
            this.Controls.Add(this.buttonGenerarLlamada);
            this.Name = "Central";
            this.Text = "Central Telefonica";
            this.Load += new System.EventHandler(this.Central_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonGenerarLlamada;
        private System.Windows.Forms.Button buttonFacturacionTotal;
        private System.Windows.Forms.Button buttonFacturacionLocal;
        private System.Windows.Forms.Button buttonFacturacionProvincial;
        private System.Windows.Forms.Button buttonSalir;
    }
}

