using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    public class Pesos
    {
        private double cantidad;
        private static float cotizRespectoDolar;

        public Pesos(double inCantidad) : this()
        {
            this.cantidad = inCantidad;
        }
        public Pesos(double inCantidad, float inCotizacion) : this(inCantidad)
        {
            Pesos.cotizRespectoDolar = inCotizacion;
        }

        private Pesos()
        {
            Pesos.cotizRespectoDolar = (float)17.55;
        }
        //---------------------------------------GETS-----------------------------------------------
        public static float GetCotizacion()
        {
            return Pesos.cotizRespectoDolar;
        }
       
        public double GetCantidad()
        {
            return this.cantidad;
        }
        //----------------------------------------SOBRECARGAS----------------------------------------
        public static explicit operator Dolar(Pesos pesos)
        {
            Dolar retorno = new Dolar(pesos.cantidad / Pesos.GetCotizacion());

            return retorno;
        }

        public static explicit operator Euro(Pesos pesos)
        {// obtengo la cantidad de pesos divido por la cotizacion y lo multiplico por la cotizacion del euro
            Euro retorno = new Euro((pesos.cantidad / Pesos.GetCotizacion()) * Euro.GetCotizacion());
            return retorno;
        }
        public static implicit operator Pesos(double cantidad)
        {
            Pesos retorno = new Pesos(cantidad);
            return retorno;
        }
        //-----------------------------------SOBRECARGA OPERADORES DE COMPARACION--------------------------------
        public static bool operator ==(Pesos pesos, Euro euro)
        {
            bool retorno = false;
            if (pesos.GetCantidad() == euro.GetCantidad())
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Pesos pesos, Euro euro)
        {
            bool retorno = false;
            if (!(pesos == euro))
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator ==(Pesos pesos, Dolar dolar)
        {
            bool retorno = false;
            if (pesos.GetCantidad() == dolar.GetCantidad())
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Pesos pesos, Dolar dolar)
        {
            bool retorno = false;
            if (!(pesos == dolar))
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator ==(Pesos pesosA, Pesos pesosB)
        {
            bool retorno = false;
            if (pesosA.GetCantidad() == pesosB.GetCantidad())
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Pesos pesosA, Pesos pesosB)
        {
            bool retorno = false;
            if (!(pesosA == pesosB))
            {
                retorno = true;
            }
            return retorno;
        }
        //----------------------------------------SOBRECARGA DE OPERADORES----------------------------------------

        public static Pesos operator +(Pesos pesos, Euro euro)
        {
               //divido la cantidad de pesos por la cotizacion sumo la cantidad de euros por su cotizacion
            double conversion = (pesos.GetCantidad() / Pesos.GetCotizacion()) + (Euro.GetCotizacion()* euro.GetCantidad());
            Pesos retorno = new Pesos(conversion);

            return retorno;
        }
        public static Pesos operator -(Pesos pesos, Euro euro)
        {
            double conversion = (pesos.GetCantidad() / Pesos.GetCotizacion()) - (Euro.GetCotizacion() * euro.GetCantidad());
            Pesos retorno = new Pesos(conversion);

            return retorno;
        }
        public static Pesos operator +(Pesos pesos, Dolar dolar)
        {
            double conversion = (pesos.GetCantidad() / Pesos.GetCotizacion()) + dolar.GetCantidad();
            Pesos retorno = new Pesos(conversion);

            return retorno;
        }

        public static Pesos operator -(Pesos pesos, Dolar dolar)
        {
            double conversion = (pesos.GetCantidad() / Pesos.GetCotizacion()) + dolar.GetCantidad();
            Pesos retorno = new Pesos(conversion);

            return retorno;
        }

    }
}
