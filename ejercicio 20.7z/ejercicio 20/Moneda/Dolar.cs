using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    public class Dolar
    {
        private double cantidad;
        private static float cotizRespectoDolar;

        //----------------------------------------constructores----------------------------------------
        public Dolar(double inCantidad) : this()
        {
            this.cantidad = inCantidad;
        }
        public Dolar(double inCantidad, float inCotizacion) : this(inCantidad)
        {
            Dolar.cotizRespectoDolar = inCotizacion;
        }

        private Dolar()
        {
            Dolar.cotizRespectoDolar = 1;
        }
        //----------------------------------------GETS----------------------------------------
        public static float GetCotizacion()
        {
            return Dolar.cotizRespectoDolar;
        }
        public double GetCantidad()
        {
            return this.cantidad;
        }
        //----------------------------------------SOBRECARGAS----------------------------------------
        public static explicit operator Euro(Dolar dolar)
        {
            Euro retorno = new Euro(dolar.cantidad * Euro.GetCotizacion());

            return retorno;
        }

        public static explicit operator Pesos(Dolar dolar)
        {
            Pesos retorno = new Pesos(dolar.cantidad * Pesos.GetCotizacion());
            return retorno;
        }
        public static implicit operator Dolar(double cantidad)
        {
            Dolar retorno = new Dolar(cantidad);
            return retorno;
        }
        //-----------------------------------SOBRECARGA OPERADORES DE COMPARACION--------------------------------
        public static bool operator ==(Dolar dolar, Euro euro)
        {
            bool retorno = false;
            if(dolar.GetCantidad() == euro.GetCantidad())
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Dolar dolar, Euro euro)
        {
            bool retorno = false;
            if (!(dolar==euro))
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator ==(Dolar dolar, Pesos pesos)
        {
            bool retorno = false;
            if(dolar.GetCantidad() == pesos.GetCantidad())
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Dolar dolar, Pesos pesos)
        {
            bool retorno = false;
            if (!(dolar==pesos))
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator ==(Dolar dolarA, Dolar dolarB)
        {
            bool retorno = false;
            if (dolarA.GetCantidad() == dolarB.GetCantidad())
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Dolar dolarA, Dolar dolarB)
        {
            bool retorno = false;
            if (!(dolarA==dolarB))
            {
                retorno = true;
            }
            return retorno;
        }
        //----------------------------------------SOBRECARGA DE OPERADORES----------------------------------------

        public static Dolar operator +(Dolar dolar, Euro euro)
        {
            //                  obtengo la cantidad multiplico por la cotizacion y le sumo la cantidad de dolar
            double conversion = (euro.GetCantidad() * Euro.GetCotizacion()) + dolar.GetCantidad();
            Dolar retorno =new Dolar(conversion);

            return retorno;
        }        
        public static Dolar operator -(Dolar dolar, Euro euro)
        {
            //                  obtengo la cantidad multiplico por la cotizacion y la resto la cantidad de dolar
            double conversion = (euro.GetCantidad() * Euro.GetCotizacion()) - dolar.GetCantidad();
            Dolar retorno = new Dolar(conversion);

            return retorno;
        }
        public static Dolar operator +(Dolar dolar, Pesos pesos)
        {
            //                  obtengo la cantidad multiplico por la cotizacion y le sumo la cantidad de dolar
            double conversion = (pesos.GetCantidad() * Pesos.GetCotizacion()) + dolar.GetCantidad();
            Dolar retorno = new Dolar(conversion);

            return retorno;
        }

        public static Dolar operator -(Dolar dolar, Pesos pesos)
        {
            //                  obtengo la cantidad multiplico por la cotizacion y le sumo la cantidad de dolar
            double conversion = (pesos.GetCantidad() * Pesos.GetCotizacion()) + dolar.GetCantidad();
            Dolar retorno = new Dolar(conversion);

            return retorno;
        }

    }
}
