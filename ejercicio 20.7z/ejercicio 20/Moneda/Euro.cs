using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Billetes
{
    public class Euro
    {
        private double cantidad;
        private static float cotizRespectoDolar;
        public Euro(double inCantidad) : this()
        {
            this.cantidad = inCantidad;
        }
        public Euro(double inCantidad, float inCotizacion) : this(inCantidad)
        {
            Euro.cotizRespectoDolar = inCotizacion;
        }

        private Euro()
        {
            Euro.cotizRespectoDolar = (float)1.3642;
        }
        public static float GetCotizacion()
        {
            return Euro.cotizRespectoDolar;
        }

        //---------------------------
        public double GetCantidad()
        {
            return this.cantidad;
        }

        public static explicit operator Dolar(Euro euro)
        {
            Dolar retorno = new Dolar(euro.cantidad * Dolar.GetCotizacion());
            return retorno;
        }

        public static explicit operator Pesos(Euro euro)
        {
            Pesos retorno = new Pesos(euro.cantidad * Pesos.GetCotizacion());
            return retorno;
        }
        public static implicit operator Euro(double cantidad)
        {
            Euro retorno = new Euro(cantidad);
            return retorno;
        }

        //-----------------------------------SOBRECARGA OPERADORES DE COMPARACION--------------------------------
        public static bool operator ==(Euro euro,Dolar dolar)
        {
            bool retorno = false;
            if (euro.GetCantidad() == dolar.GetCantidad())
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Euro euro, Dolar dolar)
        {
            bool retorno = false;
            if (!(euro == dolar))
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator ==(Euro euro, Pesos pesos)
        {
            bool retorno = false;
            if (euro.GetCantidad() == pesos.GetCantidad())
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Euro euro, Pesos pesos)
        {
            bool retorno = false;
            if (!(euro == pesos))
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator ==(Euro euroA, Euro euroB)
        {
            bool retorno = false;
            if (euroA.GetCantidad() == euroB.GetCantidad())
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Euro euroA, Euro euroB)
        {
            bool retorno = false;
            if (!(euroA == euroB))
            {
                retorno = true;
            }
            return retorno;
        }
        //----------------------------------------SOBRECARGA DE OPERADORES----------------------------------------

        public static Euro operator +(Euro euro, Dolar dolar)
        {
            double conversion = (euro.GetCantidad() * Euro.GetCotizacion()) + dolar.GetCantidad();
            Euro retorno = new Euro(conversion);

            return retorno;
        }
        public static Euro operator -(Euro euro, Dolar dolar)
        {
            double conversion = (euro.GetCantidad() * Euro.GetCotizacion()) - dolar.GetCantidad();
            Euro retorno = new Euro(conversion);

            return retorno;
        }
        public static Euro operator +(Euro euro, Pesos pesos)
        {
            double conversion = (pesos.GetCantidad() / Pesos.GetCotizacion()) + euro.GetCantidad() * Euro.GetCotizacion();
            Euro retorno = new Euro(conversion);

            return retorno;
        }

        public static Euro operator -(Euro euro, Pesos pesos)
        {
            double conversion = (pesos.GetCantidad() / Pesos.GetCotizacion()) - euro.GetCantidad() * Euro.GetCotizacion();
            Euro retorno = new Euro(conversion);

            return retorno;
        }
    }
}
