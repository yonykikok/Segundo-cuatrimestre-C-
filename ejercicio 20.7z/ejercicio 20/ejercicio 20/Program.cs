﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Billetes;

namespace ejercicio_20
{
    class Program
    {
        static void Main(string[] args)
        {
            Dolar dolar = new Dolar(100);
            Euro euro = new Euro(75);
            Pesos pesos = new Pesos(1700);
            Dolar dolar2 = new Dolar(0);
            Euro euro2 = new Euro(0);
            Pesos pesos2 = new Pesos(0);

            pesos2 = pesos + dolar;
            dolar2 = dolar + euro;
            euro2 = euro + dolar;

            Console.WriteLine(euro2.GetCantidad());
            Console.WriteLine(pesos2.GetCantidad());
            Console.WriteLine(dolar2.GetCantidad());

            Console.ReadKey();


        }
    }
}
