﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

using Billetes;

namespace Conversor_Dinero
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            string euroString = textBoxEuro.Text;
            double cantidadEuro;
            Pesos pesos = new Pesos(0);
            Dolar dolar = new Dolar(0);

            bool esNumerico = double.TryParse(euroString, out cantidadEuro);
            if (esNumerico)
            {
                Euro euro = new Euro(cantidadEuro);
                textBoxPesosOut.Text = Convert.ToString(euro.GetCantidad() * Pesos.GetCotizacion());
                textBoxDolarOut.Text = Convert.ToString(euro.GetCantidad() * Euro.GetCotizacion());
                textBoxEuroOut.Text = textBoxEuro.Text;
            }
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string dolarString = textBoxDolar.Text;
            double cantidadDolar;
            Pesos pesos = new Pesos(0);
            Euro euro = new Euro(0);

            bool esNumerico = double.TryParse(dolarString, out cantidadDolar);
            if (esNumerico)
            {
                Dolar dolar = new Dolar(cantidadDolar);
                textBoxPesosOut2.Text = Convert.ToString(dolar.GetCantidad() * Pesos.GetCotizacion());
                textBoxEuroOut2.Text = Convert.ToString(Euro.GetCotizacion()/dolar.GetCantidad());
                textBoxDolarOut2.Text = textBoxDolar.Text;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string pesosString = textBoxPesos.Text;
            double cantidadPesos;
            Euro euro = new Euro(0);
            Dolar dolar = new Dolar(0);

            bool esNumerico = double.TryParse(pesosString, out cantidadPesos);
            if (esNumerico)
            {
                Pesos pesos = new Pesos(cantidadPesos);
                textBoxDolarOut3.Text = Convert.ToString(pesos.GetCantidad() / Pesos.GetCotizacion());
                textBoxEuroOut3.Text = Convert.ToString(pesos.GetCantidad() / Pesos.GetCotizacion() / Euro.GetCotizacion());
                textBoxPesosOut3.Text = textBoxPesos.Text;
            }
        }
    }
}
