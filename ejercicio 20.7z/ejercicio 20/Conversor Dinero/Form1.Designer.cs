﻿namespace Conversor_Dinero
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.button3 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.button2 = new System.Windows.Forms.Button();
            this.textBoxEuroOut = new System.Windows.Forms.TextBox();
            this.textBoxEuroOut2 = new System.Windows.Forms.TextBox();
            this.textBoxDolarOut2 = new System.Windows.Forms.TextBox();
            this.textBoxPesosOut2 = new System.Windows.Forms.TextBox();
            this.textBoxEuroOut3 = new System.Windows.Forms.TextBox();
            this.textBoxDolarOut3 = new System.Windows.Forms.TextBox();
            this.textBoxPesosOut3 = new System.Windows.Forms.TextBox();
            this.textBoxEuro = new System.Windows.Forms.TextBox();
            this.textBoxDolar = new System.Windows.Forms.TextBox();
            this.textBoxPesos = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.textBoxDolarOut = new System.Windows.Forms.TextBox();
            this.textBoxPesosOut = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(279, 149);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(133, 35);
            this.button3.TabIndex = 2;
            this.button3.Text = "->";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(279, 108);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(133, 35);
            this.button1.TabIndex = 3;
            this.button1.Text = "->";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(279, 67);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(133, 35);
            this.button2.TabIndex = 4;
            this.button2.Text = "->";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // textBoxEuroOut
            // 
            this.textBoxEuroOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEuroOut.Location = new System.Drawing.Point(430, 67);
            this.textBoxEuroOut.Name = "textBoxEuroOut";
            this.textBoxEuroOut.Size = new System.Drawing.Size(160, 35);
            this.textBoxEuroOut.TabIndex = 5;
            // 
            // textBoxEuroOut2
            // 
            this.textBoxEuroOut2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEuroOut2.Location = new System.Drawing.Point(430, 108);
            this.textBoxEuroOut2.Name = "textBoxEuroOut2";
            this.textBoxEuroOut2.Size = new System.Drawing.Size(160, 35);
            this.textBoxEuroOut2.TabIndex = 8;
            // 
            // textBoxDolarOut2
            // 
            this.textBoxDolarOut2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDolarOut2.Location = new System.Drawing.Point(596, 108);
            this.textBoxDolarOut2.Name = "textBoxDolarOut2";
            this.textBoxDolarOut2.Size = new System.Drawing.Size(160, 35);
            this.textBoxDolarOut2.TabIndex = 9;
            // 
            // textBoxPesosOut2
            // 
            this.textBoxPesosOut2.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPesosOut2.Location = new System.Drawing.Point(762, 108);
            this.textBoxPesosOut2.Name = "textBoxPesosOut2";
            this.textBoxPesosOut2.Size = new System.Drawing.Size(160, 35);
            this.textBoxPesosOut2.TabIndex = 10;
            // 
            // textBoxEuroOut3
            // 
            this.textBoxEuroOut3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEuroOut3.Location = new System.Drawing.Point(430, 149);
            this.textBoxEuroOut3.Name = "textBoxEuroOut3";
            this.textBoxEuroOut3.Size = new System.Drawing.Size(160, 35);
            this.textBoxEuroOut3.TabIndex = 11;
            // 
            // textBoxDolarOut3
            // 
            this.textBoxDolarOut3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDolarOut3.Location = new System.Drawing.Point(596, 149);
            this.textBoxDolarOut3.Name = "textBoxDolarOut3";
            this.textBoxDolarOut3.Size = new System.Drawing.Size(160, 35);
            this.textBoxDolarOut3.TabIndex = 12;
            // 
            // textBoxPesosOut3
            // 
            this.textBoxPesosOut3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPesosOut3.Location = new System.Drawing.Point(762, 149);
            this.textBoxPesosOut3.Name = "textBoxPesosOut3";
            this.textBoxPesosOut3.Size = new System.Drawing.Size(160, 35);
            this.textBoxPesosOut3.TabIndex = 13;
            // 
            // textBoxEuro
            // 
            this.textBoxEuro.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxEuro.Location = new System.Drawing.Point(95, 67);
            this.textBoxEuro.Name = "textBoxEuro";
            this.textBoxEuro.Size = new System.Drawing.Size(160, 35);
            this.textBoxEuro.TabIndex = 14;
            // 
            // textBoxDolar
            // 
            this.textBoxDolar.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDolar.Location = new System.Drawing.Point(95, 108);
            this.textBoxDolar.Name = "textBoxDolar";
            this.textBoxDolar.Size = new System.Drawing.Size(160, 35);
            this.textBoxDolar.TabIndex = 15;
            // 
            // textBoxPesos
            // 
            this.textBoxPesos.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPesos.Location = new System.Drawing.Point(95, 149);
            this.textBoxPesos.Name = "textBoxPesos";
            this.textBoxPesos.Size = new System.Drawing.Size(160, 35);
            this.textBoxPesos.TabIndex = 16;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 13);
            this.label1.TabIndex = 17;
            this.label1.Text = "Euro";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 119);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(32, 13);
            this.label2.TabIndex = 18;
            this.label2.Text = "Dolar";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 164);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(36, 13);
            this.label3.TabIndex = 19;
            this.label3.Text = "Pesos";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(486, 39);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(57, 25);
            this.label4.TabIndex = 20;
            this.label4.Text = "Euro";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(642, 39);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(63, 25);
            this.label5.TabIndex = 21;
            this.label5.Text = "Dolar";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(808, 39);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(72, 25);
            this.label6.TabIndex = 22;
            this.label6.Text = "Pesos";
            // 
            // textBoxDolarOut
            // 
            this.textBoxDolarOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxDolarOut.Location = new System.Drawing.Point(596, 67);
            this.textBoxDolarOut.Name = "textBoxDolarOut";
            this.textBoxDolarOut.Size = new System.Drawing.Size(160, 35);
            this.textBoxDolarOut.TabIndex = 23;
            this.textBoxDolarOut.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBoxPesosOut
            // 
            this.textBoxPesosOut.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxPesosOut.Location = new System.Drawing.Point(762, 67);
            this.textBoxPesosOut.Name = "textBoxPesosOut";
            this.textBoxPesosOut.Size = new System.Drawing.Size(160, 35);
            this.textBoxPesosOut.TabIndex = 24;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(984, 212);
            this.Controls.Add(this.textBoxPesosOut);
            this.Controls.Add(this.textBoxDolarOut);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.textBoxPesos);
            this.Controls.Add(this.textBoxDolar);
            this.Controls.Add(this.textBoxEuro);
            this.Controls.Add(this.textBoxPesosOut3);
            this.Controls.Add(this.textBoxDolarOut3);
            this.Controls.Add(this.textBoxEuroOut3);
            this.Controls.Add(this.textBoxPesosOut2);
            this.Controls.Add(this.textBoxDolarOut2);
            this.Controls.Add(this.textBoxEuroOut2);
            this.Controls.Add(this.textBoxEuroOut);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.button3);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox textBoxEuroOut;
        private System.Windows.Forms.TextBox textBoxEuroOut2;
        private System.Windows.Forms.TextBox textBoxDolarOut2;
        private System.Windows.Forms.TextBox textBoxPesosOut2;
        private System.Windows.Forms.TextBox textBoxEuroOut3;
        private System.Windows.Forms.TextBox textBoxDolarOut3;
        private System.Windows.Forms.TextBox textBoxPesosOut3;
        private System.Windows.Forms.TextBox textBoxEuro;
        private System.Windows.Forms.TextBox textBoxDolar;
        private System.Windows.Forms.TextBox textBoxPesos;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox textBoxDolarOut;
        private System.Windows.Forms.TextBox textBoxPesosOut;
    }
}

