using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CentralitaHerencia;
using System.Text.RegularExpressions;

namespace FormLlamador
{
    public partial class FormLlamador : Form
    {
        private Centralita miCentralita;

       public Centralita Centralita
       {
          get
          {
            return this.Centralita;
          }
       }
        public FormLlamador(Centralita centralita)
        {
            this.miCentralita = centralita;
            InitializeComponent();
        }      

        private void FormLlamador_Load(object sender, EventArgs e)
        {

        }

    private void textBoxNumeroDestino_TextChanged(object sender, EventArgs e)
    {
      textBoxNumeroDestino.Text = Regex.Replace(textBoxNumeroDestino.Text, "[a-zA-Z]+", "");
    }
    private void button1_Click(object sender, EventArgs e)
    {
      textBoxNumeroDestino.Text += button1.Text;
    }

    private void button2_Click(object sender, EventArgs e)
    {
      textBoxNumeroDestino.Text += button2.Text;
    }   

    private void button3_Click(object sender, EventArgs e)
    {
      textBoxNumeroDestino.Text += button3.Text;
    }

    private void button4_Click(object sender, EventArgs e)
    {
      textBoxNumeroDestino.Text += button4.Text;
    }

    private void button5_Click(object sender, EventArgs e)
    {
      textBoxNumeroDestino.Text += button5.Text;
    }

    private void button6_Click(object sender, EventArgs e)
    {
      textBoxNumeroDestino.Text += button6.Text;
    }

    private void button7_Click(object sender, EventArgs e)
    {
      textBoxNumeroDestino.Text += button7.Text;
    }

    private void button8_Click(object sender, EventArgs e)
    {
      textBoxNumeroDestino.Text += button8.Text;
    }

    private void button9_Click(object sender, EventArgs e)
    {
      textBoxNumeroDestino.Text += button9.Text;
    }

    private void buttonAsterisco_Click(object sender, EventArgs e)
    {
      textBoxNumeroDestino.Text += buttonAsterisco.Text;
    }

    private void buttonSharp_Click(object sender, EventArgs e)
    {
      textBoxNumeroDestino.Text += buttonSharp.Text;
    }

    private void button10_Click(object sender, EventArgs e)
    {
      textBoxNumeroDestino.Text += button10.Text;
    }
  }
}
