﻿namespace WindowForm
{
    partial class FormMenu
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.buttonGenerarLlamada = new System.Windows.Forms.Button();
            this.buttonTotal = new System.Windows.Forms.Button();
            this.buttonLocal = new System.Windows.Forms.Button();
            this.buttonProvincial = new System.Windows.Forms.Button();
            this.buttonSalir = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // buttonGenerarLlamada
            // 
            this.buttonGenerarLlamada.Location = new System.Drawing.Point(72, 21);
            this.buttonGenerarLlamada.Name = "buttonGenerarLlamada";
            this.buttonGenerarLlamada.Size = new System.Drawing.Size(363, 73);
            this.buttonGenerarLlamada.TabIndex = 0;
            this.buttonGenerarLlamada.Text = "Generar Llamada";
            this.buttonGenerarLlamada.UseVisualStyleBackColor = true;
            this.buttonGenerarLlamada.Click += new System.EventHandler(this.buttonGenerarLlamada_Click);
            // 
            // buttonTotal
            // 
            this.buttonTotal.Location = new System.Drawing.Point(72, 100);
            this.buttonTotal.Name = "buttonTotal";
            this.buttonTotal.Size = new System.Drawing.Size(363, 73);
            this.buttonTotal.TabIndex = 1;
            this.buttonTotal.Text = "Facturacion Total";
            this.buttonTotal.UseVisualStyleBackColor = true;
            // 
            // buttonLocal
            // 
            this.buttonLocal.Location = new System.Drawing.Point(72, 179);
            this.buttonLocal.Name = "buttonLocal";
            this.buttonLocal.Size = new System.Drawing.Size(363, 73);
            this.buttonLocal.TabIndex = 2;
            this.buttonLocal.Text = "Facturacion Local";
            this.buttonLocal.UseVisualStyleBackColor = true;
            // 
            // buttonProvincial
            // 
            this.buttonProvincial.Location = new System.Drawing.Point(72, 258);
            this.buttonProvincial.Name = "buttonProvincial";
            this.buttonProvincial.Size = new System.Drawing.Size(363, 73);
            this.buttonProvincial.TabIndex = 3;
            this.buttonProvincial.Text = "Facturacion Provincial";
            this.buttonProvincial.UseVisualStyleBackColor = true;
            // 
            // buttonSalir
            // 
            this.buttonSalir.Location = new System.Drawing.Point(72, 337);
            this.buttonSalir.Name = "buttonSalir";
            this.buttonSalir.Size = new System.Drawing.Size(363, 73);
            this.buttonSalir.TabIndex = 4;
            this.buttonSalir.Text = "Salir";
            this.buttonSalir.UseVisualStyleBackColor = true;
            // 
            // FormMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(503, 450);
            this.Controls.Add(this.buttonSalir);
            this.Controls.Add(this.buttonProvincial);
            this.Controls.Add(this.buttonLocal);
            this.Controls.Add(this.buttonTotal);
            this.Controls.Add(this.buttonGenerarLlamada);
            this.Name = "FormMenu";
            this.Text = "Central Telefonica";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button buttonGenerarLlamada;
        private System.Windows.Forms.Button buttonTotal;
        private System.Windows.Forms.Button buttonLocal;
        private System.Windows.Forms.Button buttonProvincial;
        private System.Windows.Forms.Button buttonSalir;
    }
}

