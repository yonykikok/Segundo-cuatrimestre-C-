using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CentralitaHerencia;
namespace WindowForm
{
  public partial class FormMenu : Form
  {

    public FormMenu()
    {
      InitializeComponent();
    }

    private void Form1_Load(object sender, EventArgs e)
    {
     
    }

    private void buttonGenerarLlamada_Click(object sender, EventArgs e)
    {
      Centralita miCentralita = new Centralita("Multitask");
      FormLlamador.FormLlamador llamador = new FormLlamador.FormLlamador(miCentralita);
      llamador.ShowDialog();
    }
  }
}
