using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace CentralitaHerencia
{
    public class Centralita
    {
        private List<Llamada> listaDeLlamadas;
        protected string razonSocial;

        public Centralita()
        {
            this.listaDeLlamadas = new List<Llamada>();
            this.razonSocial = string.Empty;
        }
        public Centralita(string nombreEmpresa)
        {
            this.listaDeLlamadas = new List<Llamada>();
            this.razonSocial = nombreEmpresa;
        }
        private float CalcularGanancia(Llamada.TipoLlamada tipo)
        {
            float retornoProvincial = 0;
            float retornoLocal = 0;
            float retornoTotal = 0;
            foreach (Llamada llamada in listaDeLlamadas)
            {
                if (llamada is Local)
                {
                    Local llamadaLocal = (Local)llamada;
                    retornoLocal += llamadaLocal.CostoLlamada;
                    retornoTotal += llamadaLocal.CostoLlamada;
                }
                else
                {
                    Provincial llamadaProvincial = (Provincial)llamada;
                    retornoProvincial += llamadaProvincial.CostoLlamada;
                    retornoTotal += llamadaProvincial.CostoLlamada;

                }
            }
            switch (tipo)
            {
                case Llamada.TipoLlamada.Local:
                    return retornoLocal;
                case Llamada.TipoLlamada.Provincial:
                    return retornoProvincial;
                default:
                    return retornoTotal;
            }
        }

        public float GananciaPorLocal
        {
            get
            {
                return CalcularGanancia(Llamada.TipoLlamada.Local);
            }
        }
        public float GananciaPorProvincial
        {
            get
            {
                return CalcularGanancia(Llamada.TipoLlamada.Provincial);
            }
        }
        public float GananciaPorTotal
        {
            get
            {
                return CalcularGanancia(Llamada.TipoLlamada.Todas);
            }
        }
        public List<Llamada> Llamadas
        {
            get
            {
                return this.listaDeLlamadas;
            }
        }

        public string Mostrar()
        {

            StringBuilder retorno = new StringBuilder();
            retorno.AppendLine("Razon Social: " + this.razonSocial);
            retorno.AppendLine("Ganancia Total: " + this.GananciaPorTotal);
            retorno.AppendLine("Ganancia Local: " + this.GananciaPorLocal);
            retorno.AppendLine("Ganancia Provincial: " + this.GananciaPorProvincial);

            foreach (Llamada llamada in this.listaDeLlamadas)
            {
                if (llamada is Local)
                {
                    Local llamadaLocal = (Local)llamada;
                    retorno.AppendLine(llamadaLocal.ToString());
                }
                else if (llamada is Provincial)
                {
                    Provincial llamadaProvincial = (Provincial)llamada;
                    retorno.AppendLine(llamadaProvincial.ToString());
                }
            }

            return retorno.ToString();
        }
        public void OrdenarLlamadas()
        {
            this.listaDeLlamadas.Sort(Llamada.OrdenarPorDuracion);
        }
        private void AgregarLlamada(Llamada nuevaLlamada)
        {
            this.listaDeLlamadas.Add(nuevaLlamada);
        }
        public static bool operator ==(Centralita centralita, Llamada llamada)
        {
            bool retorno = false;
            foreach (Llamada estaLlamada in centralita.listaDeLlamadas)
            {
                if (estaLlamada == llamada)
                {
                    retorno = true;
                    break;
                }
            }
            return retorno;
        }
        public static bool operator !=(Centralita centralita, Llamada llamada)
        {
            bool retorno = false;
            if (!(centralita == llamada))
            {
                retorno = true;
            }
            return retorno;
        }
        public static Centralita operator +(Centralita centralita, Llamada nuevaLlamada)
        {
            if(centralita!=nuevaLlamada)
            {
                centralita.AgregarLlamada(nuevaLlamada);
            }
            return centralita;
        }
    }
}
