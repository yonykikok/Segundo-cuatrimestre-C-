﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Local : Llamada
    {
        protected float costo;

        public override float CostoLlamada// porque motivo se debe usar el new? 
        {
            get
            {
                return CalcularCosto();
            }
        }
        public override string ToString()
        {
            return this.Mostrar();
        }
        public override bool Equals(object obj)
        {
            bool retorno = false;
            if (obj != null && obj is Local)
            {
                retorno = true;
            }
            return retorno;
        }

        private float CalcularCosto()
        {
            return this.duracion * this.costo;//calcula el costo de la llamada
        }
        public Local(Llamada llamada, float costo) : base(llamada.Duracion, llamada.NroDestino, llamada.NroOrigen)
        {
            this.costo = costo;
        }
        public Local(string origen, float duracion, string destino, float costo) : base(duracion, destino, origen)
        {
            this.costo = costo;
        }
        protected override string Mostrar()
        {
            StringBuilder miString = new StringBuilder();
            miString.AppendLine(base.Mostrar());
            miString.Append("Costo Llamada: ");
            miString.AppendLine(Convert.ToString(this.CostoLlamada));
            return miString.ToString();
        }
    }
}
