﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Provincial : Llamada
    {
        protected Franja franjaHoraria;

        public enum Franja
        {
            Franja_1,
            Franja_2,
            Franja_3
        }

        public override float CostoLlamada
        {
            get
            {
                return CalcularCosto();
            }
        }
        private float CalcularCosto()
        {
            float retorno;
            if (Franja.Franja_1 == this.franjaHoraria)
            {
                retorno = duracion * (float)0.99;
            }
            else if (Franja.Franja_2 == this.franjaHoraria)
            {
                retorno = duracion * (float)1.25;
            }
            else
            {
                retorno = duracion * (float)0.66;
            }
            return retorno;
        }

        public override bool Equals(object obj)
        {
            bool retorno = false;
            if (obj != null && obj is Provincial)
            {
                retorno = true;
            }
            return retorno;
        }

        public override string ToString()
        {
            return this.Mostrar();
        }
        public Provincial(Franja miFranja, Llamada llamada) : base(llamada.Duracion, llamada.NroDestino, llamada.NroOrigen)
        {
            this.franjaHoraria = miFranja;

        }
        public Provincial(string origen, Franja miFranja, float duracion, string destino) : base(duracion, destino, origen)
        {
            this.franjaHoraria = miFranja;
        }

        protected override string Mostrar()
        {
            StringBuilder retorno= new StringBuilder();
            retorno.AppendLine(base.Mostrar());
            retorno.Append("Costo Llamada: ");
            retorno.AppendLine(Convert.ToString( this.CostoLlamada) );
            retorno.Append("Franja Horaria: ");
            retorno.AppendLine(Convert.ToString( this.franjaHoraria) );

            return retorno.ToString();
        }
    }
}
