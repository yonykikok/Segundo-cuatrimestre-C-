using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using CentralitaHerencia;
namespace Test
{
    class Program
    {
        static void Main(string[] args)
        {
            // Mi central 
            Random numRandom = new Random();
            Centralita miCentral = new Centralita("Fede Center");


            // Mis 4 llamadas 
            Local local1 = new Local("Bernal", numRandom.Next(1, 100), "Rosario", 2.65f);
            Provincial provincial1 = new Provincial("Morón", Provincial.Franja.Franja_1, 21, "Bernal");
            Local local2 = new Local("Lanús", numRandom.Next(1, 100), "San Rafael", 1.99f);
            Provincial provincial2 = new Provincial(Provincial.Franja.Franja_3, provincial1);

            // Las llamadas se irán registrando en la Centralita. 
            // La centralita mostrará por pantalla todas las llamadas según las vaya registrando. 

            miCentral += local1;
            Console.WriteLine(miCentral.Mostrar());

            miCentral += local2;
            Console.WriteLine(miCentral.Mostrar());

            miCentral += provincial1;
            Console.WriteLine(miCentral.Mostrar());

            miCentral += provincial2;
            Console.WriteLine(miCentral.Mostrar());

            Console.ReadKey();
            Console.Clear();

            miCentral.OrdenarLlamadas();

            Console.WriteLine(miCentral.Mostrar());

            Console.ReadKey();
        }
    }
}
