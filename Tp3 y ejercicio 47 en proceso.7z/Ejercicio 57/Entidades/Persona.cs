﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Runtime.Serialization;

namespace Entidades
{
    [Serializable]
    public class Persona
    {
        private string nombre;
        private string apellido;

        public Persona(string nombre, string apellido)
        {
            this.nombre = nombre;
            this.apellido = apellido;
        }
        public static void Guardar(Persona persona)
        {
            BinaryFormatter binario = new BinaryFormatter();
            FileStream archivo = new FileStream("personsa", FileMode.Create);
            binario.Serialize(archivo, persona);
            archivo.Close();
        }
        public static Persona Leer()
        {
            Persona persona=null;
            BinaryFormatter binario = new BinaryFormatter();
            FileStream archivo = null;
            try
            {
                archivo = new FileStream("ARchivo", FileMode.Open);
                persona = (Persona)binario.Deserialize(archivo);
            }
            catch (FileNotFoundException)
            {
                Console.WriteLine("No se encontro el archivo.");
                archivo=new FileStream("ARchivo", FileMode.Create);
                archivo.Close();

            }
            catch (SerializationException)
            {
                Console.WriteLine("El Archivo Esta Vacio");
            }
            finally
            {
                if (!(archivo is null))
                {
                    archivo.Close();
                }
            }
            return persona;
        }
        public override string ToString()
        {
            StringBuilder retorno = new StringBuilder();
            retorno.AppendLine("Nombre: " + this.nombre);
            retorno.AppendLine("Apellido: " + this.apellido);
            return retorno.ToString();
        }

    }
}
