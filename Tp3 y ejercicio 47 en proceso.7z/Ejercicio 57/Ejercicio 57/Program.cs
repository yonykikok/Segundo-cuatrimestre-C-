﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades;
namespace Ejercicio_57
{
    class Program
    {
        static void Main(string[] args)
        {
            Persona miPersona = new Persona("Jonathan", "Haedo");
            Persona miPersonita2;
            Persona.Guardar(miPersona);
            miPersonita2 = Persona.Leer();
            Console.WriteLine(miPersonita2);
            Console.ReadKey();
        }
    }
}
