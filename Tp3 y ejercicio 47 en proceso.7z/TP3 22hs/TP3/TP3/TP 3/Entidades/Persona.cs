﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;

namespace Entidades
{
    public abstract class Persona
    {
        public enum ENacionalidad
        {
            Argentino,
            Extranjero
        }
        private int dni;
        private string nombre;
        private string apellido;
        private ENacionalidad nacionalidad;

        public string Apellido
        {
            get
            {
                return this.apellido;
            }
            set
            {
                this.apellido = value;
            }
        }
        public string Nombre
        {
            get
            {
                return this.nombre;
            }
            set
            {
                this.nombre = value;
            }
        }
        public ENacionalidad Nacionalidad
        {
            get
            {
                return this.nacionalidad;
            }
            set
            {
                this.nacionalidad = value;
            }
        }
        public int DNI
        {
            get
            {
                return this.dni;
            }
            set
            {
                this.dni = value;
            }
        }
        public string StringToDNI
        {
            set
            {

            }
        }
        public Persona()
        {

        }
        public Persona(string nombre, string apellido, ENacionalidad nacionalidad)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.nacionalidad = nacionalidad;
        }
        public Persona(string nombre, string apellido, int dni, ENacionalidad nacionalidad)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.nacionalidad = nacionalidad;
            this.dni = dni;
        }
        public Persona(string nombre, string apellido, string dni, ENacionalidad nacionalidad)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.nacionalidad = nacionalidad;
            this.StringToDNI = dni;/// revisar al terminar las clases.
        }
        ///
        public override string ToString()
        {//cambiar por propiedades------------------------------------------------
            StringBuilder retorno = new StringBuilder();
            retorno.AppendFormat("Nombre: {0,10}\n", this.nombre);
            retorno.AppendFormat("Apellido:{ 1,10}\n", this.apellido);
            retorno.AppendFormat("DNI:{ 3,10}\n", this.dni);
            retorno.AppendFormat("Nacionalidad:{ 2,10}\n", this.nacionalidad);
            return retorno.ToString();
        }
        /// 
        private int ValidarDni(ENacionalidad nacionalidad, int dato)
        {
            int retorno = -1;
            string auxDato = dato.ToString();
            try
            {
                retorno = ValidarDni(nacionalidad, auxDato);
            }
            catch///----------------------------------------------
            {

            }
            return retorno;

        }

        private int ValidarDni(ENacionalidad nacionalidad, string dato)
        {
            int retorno = -1;
            int auxDni;
            Regex soloNumeros = new Regex("^[0-9]+?$");
            try
            {
                if (soloNumeros.IsMatch(dato))//si el "Dato" es solo numeros continuar
                {
                    bool validacion = Int32.TryParse(dato, out auxDni);
                    if (validacion)
                    {
                        if ((nacionalidad == ENacionalidad.Argentino) && (auxDni > 0) && (auxDni <= 89999999))
                        {
                            retorno = auxDni;
                        }
                        else if ((nacionalidad == ENacionalidad.Extranjero) && (auxDni >= 90000000) && (auxDni <= 99999999))
                        {
                            retorno = auxDni;
                        }
                        else
                        {
                            throw new NacionalidadInvalidaException();
                        }
                    }
                    else
                    {
                        throw new DniInvalidoException();///----------------
                    }

                }
                else
                {
                    throw new DniInvalidoException();///----------------
                }

            }
            catch (NacionalidadInvalidaException e)//-------------------------
            {

            }
            return retorno;
        }
        private string ValidarNombreApellido(string dato)
        {
            string retorno = null;
            Regex SoloLetras = new Regex("^[a-z|A-Z]+?$");
            if (SoloLetras.IsMatch(dato))
            {
                retorno = dato;
            }
            return retorno;
        }


    }
}
