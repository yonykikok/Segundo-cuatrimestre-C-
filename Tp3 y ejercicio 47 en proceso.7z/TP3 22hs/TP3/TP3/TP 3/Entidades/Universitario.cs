﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public abstract class Universitario : Persona
    {
        protected int legajo;
        public override bool Equals(object obj)//si es universitario retorna true;
        {
            bool retorno = false;
            if (obj is Universitario)
            {
                retorno = true;
            }
            return retorno;
        }
        protected virtual string MostrarDatos()
        {
            StringBuilder retorno = new StringBuilder();
            retorno.Append(base.ToString());
            retorno.AppendFormat("Legajo: {0,10}\n", this.legajo);
            return retorno.ToString();
        }


        public static bool operator ==(Universitario pg1, Universitario pg2)
        {
            bool retorno = false;
            if ((pg1.legajo == pg2.legajo) || (pg1.DNI == pg2.DNI))///falta ver que sean del mismo tipo
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Universitario pg1, Universitario pg2)
        {
            bool retorno = false;
            if (!(pg1 == pg2))
            {
                retorno = true;
            }
            return retorno;
        }

        protected abstract string ParticiparEnClase();

        public Universitario():base()
        {

        }
        public Universitario(int legajo,string nombre, string apellido, string dni,ENacionalidad nacionalidad):base(nombre,apellido,dni,nacionalidad)
        {
            this.legajo = legajo;
        }

    }
}
