﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
    public sealed class Profesor : Universitario
    {
        private Queue<Universidad.EClases> clasesDelDia;
        static Random random;

        private void _randomClases()
        {
            Array ArrayEclases = Enum.GetValues(typeof(Universidad.EClases));//creo un array con los elementos de Eclases
            // Random random = new Random();//  no instancio porque ya esta el miembro static
            Universidad.EClases randomClass = (Universidad.EClases)ArrayEclases.GetValue(random.Next(ArrayEclases.Length));
            this.clasesDelDia.Enqueue(randomClass);
        }
        protected override string MostrarDatos()
        {
            StringBuilder retorno = new StringBuilder();
            retorno.Append(base.MostrarDatos());
            retorno.Append(ParticiparEnClase()); 
            return retorno.ToString();
        }
        public static bool operator ==(Profesor profesor, Universidad.EClases clase)
        {
            bool retorno = false;
            if (profesor.clasesDelDia.Contains(clase))
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Profesor profesor, Universidad.EClases clase)
        {
            bool retorno = false;
            if (!(profesor == clase))
            {
                retorno = true;
            }
            return retorno;
        }
        protected override string ParticiparEnClase()
        {
            StringBuilder retorno = new StringBuilder();
            foreach (Universidad.EClases clase in this.clasesDelDia)
            {
                retorno.AppendLine("CLASES DEL DÍA: " + clase);
            }
            return retorno.ToString(); ;
        }

        static Profesor()
        {
            random = new Random();
        }
        public Profesor():base()
        {
            this.clasesDelDia = new Queue<Universidad.EClases>();
            _randomClases();//primer clase
            _randomClases();//segunda clase
        }
        public Profesor(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad) : base(id, nombre, apellido, dni, nacionalidad)
        {
            this.clasesDelDia = new Queue<Universidad.EClases>();
            _randomClases();//primer clase
            _randomClases();//segunda clase
        }

        public override string ToString()
        {
            return this.MostrarDatos();
        }


    }
}
