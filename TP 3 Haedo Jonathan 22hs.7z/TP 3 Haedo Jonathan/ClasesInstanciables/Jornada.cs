﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
namespace ClasesInstanciables
{
    public class Jornada
    {
        private List<Alumno> alumnos;
        private Universidad.EClases clase;
        private Profesor instructor;

        public List<Alumno> Alumnos
        {
            get
            {
                return this.alumnos;
            }
            set
            {
                this.alumnos = value;
            }
        }
        public Universidad.EClases Clase
        {
            get
            {
                return this.clase;
            }
            set
            {
                this.clase = value;
            }
        }
        public Profesor Instructor
        {
            get
            {
                return this.instructor;
            }
            set
            {
                this.instructor = value;
            }
        }

        private Jornada()
        {
            this.alumnos = new List<Alumno>();
        }
        public Jornada(Universidad.EClases clase, Profesor instructor) : this()
        {
            this.clase = clase;
            this.instructor = instructor;
        }
        public static Jornada operator +(Jornada jornada, Alumno alumno)
        {
            if (jornada != alumno)
            {
                jornada.alumnos.Add(alumno);
            }
            return jornada;
        }
        public static bool operator ==(Jornada jornada, Alumno alumno)
        {
            bool retorno = false;
            foreach (Alumno auxAlumno in jornada.alumnos)
            {
                if (auxAlumno == alumno)
                {
                    retorno = true;
                }
            }
            return retorno;
        }
        public static bool operator !=(Jornada jornada, Alumno alumno)
        {
            bool retorno = false;
            if (!(jornada == alumno))
            {
                retorno = true;
            }
            return retorno;
        }
        public override string ToString()
        {
            StringBuilder retorno = new StringBuilder();
            retorno.AppendLine("Instructor: " + Instructor);
            retorno.AppendLine("Clase: " + Clase);
            foreach (Alumno auxAlumno in Alumnos)
            {
                retorno.AppendLine(auxAlumno.ToString());
            }
            return base.ToString();
        }
        public bool Guardar(Jornada jornada)
        {
            bool retorno = false;
            StreamWriter fichero;
            fichero = File.CreateText("Prueba.txt");
            fichero.Write(jornada.ToString());
            fichero.Close();

            return retorno;
        }
        public string Leer()
        {
            StreamReader fichero;
            fichero = File.OpenText("prueba.txt");
            fichero.ReadToEnd();
            fichero.Close();
            return fichero.ToString();
        }

    }
}
