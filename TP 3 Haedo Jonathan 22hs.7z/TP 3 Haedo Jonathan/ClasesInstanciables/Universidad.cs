﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excepciones;
namespace ClasesInstanciables
{
    public class Universidad
    {
        public enum EClases
        {
            Programacion,
            Laboratorio,
            Legislacion,
            SPD
        }
        private List<Alumno> alumnos;
        private List<Jornada> jornada;
        private List<Profesor> profesores;

        public List<Jornada> Jornada
        {
            get
            {
                return this.jornada;
            }
            set
            {

            }
        }
        public List<Profesor> Profesor
        {
            get
            {
                return this.profesores;
            }
            set
            {

            }
        }
        public List<Alumno> Alumnos
        {
            get
            {
                return this.alumnos;
            }
            set
            {

            }
        }
        public Jornada this[int i]
        {
            get
            {
                return this[i];

            }
            set
            {

            }
        }

        public static bool operator ==(Universidad universidad, Alumno alumno)
        {
            bool retorno = false;
            foreach (Alumno auxAlumno in universidad.alumnos)
            {
                if (alumno == auxAlumno)
                {
                    retorno = true;
                }
            }
            return retorno;
        }
        public static bool operator !=(Universidad universidad, Alumno alumno)
        {
            bool retorno = false;
            if (!(universidad == alumno))
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator ==(Universidad universidad, Profesor instructor)
        {
            bool retorno = false;
            foreach (Profesor auxInstructor in universidad.profesores)
            {
                if (instructor == auxInstructor)
                {
                    retorno = true;
                }
            }
            return retorno;
        }
        public static bool operator !=(Universidad universidad, Profesor instructor)
        {
            bool retorno = false;

            if (!(universidad == instructor))
            {
                retorno = true;
            }

            return retorno;
        }
        public static Profesor operator ==(Universidad universidad, EClases clase)
        {
            foreach (Profesor auxProfesor in universidad.profesores)
            {
                if (auxProfesor == clase)
                {
                    return auxProfesor;
                }
            }
            throw new SinProfesorException();
        }
        public static Profesor operator !=(Universidad universidad, EClases clase)
        {
            Profesor retorno = null;
            foreach (Profesor auxProfesor in universidad.profesores)
            {
                if (auxProfesor != clase)
                {
                    return auxProfesor;
                }
            }
            return retorno;
        }

        private static string MostrarDatos()
        {
            StringBuilder retorno = new StringBuilder();        
            
            return retorno.ToString();
        }

    }
}
