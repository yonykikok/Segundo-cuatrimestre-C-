﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ClasesAbstractas;
namespace ClasesInstanciables
{
    public sealed class Alumno : Universitario
    {
        public enum EEstadoCuenta
        {
            AlDia,
            Deudor,
            Becado
        }
        private Universidad.EClases claseQueToma;
        private EEstadoCuenta estadoCuenta;

        public Alumno()
        {

        }
        public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad, Universidad.EClases claseQueToma) : base(id, nombre, apellido, dni, nacionalidad)
        {
            this.claseQueToma = claseQueToma;
        }
        public Alumno(int id, string nombre, string apellido, string dni, ENacionalidad nacionalidad, Universidad.EClases claseQueToma, EEstadoCuenta estadoCuenta) : this(id, nombre, apellido, dni, nacionalidad, claseQueToma)
        {
            this.claseQueToma = claseQueToma;
            this.estadoCuenta = estadoCuenta;
        }
        protected override string MostrarDatos()
        {
            StringBuilder retorno = new StringBuilder();
            retorno.Append(base.MostrarDatos());
            retorno.AppendFormat("Clase : {0,10}\n", this.claseQueToma);
            retorno.AppendFormat("Estado Cuenta: {0,10}\n", this.estadoCuenta);
            return retorno.ToString();
        }
        public static bool operator ==(Alumno alumno, Universidad.EClases clase)
        {
            bool retorno = false;
            if ((alumno.estadoCuenta != EEstadoCuenta.Deudor) && (alumno.claseQueToma == clase))
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Alumno alumno, Universidad.EClases clase)
        {
            bool retorno = false;
            if (!(alumno == clase))
            {
                retorno = true;
            }
            return retorno;
        }
        protected override string ParticiparEnClase()
        {
            return "TOMA CLASE DE " + this.claseQueToma;
        }
        public override string ToString()
        {
            return this.MostrarDatos();
        }
    }
}
