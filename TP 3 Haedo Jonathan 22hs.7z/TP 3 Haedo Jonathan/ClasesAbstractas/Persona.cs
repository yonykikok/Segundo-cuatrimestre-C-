﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using Excepciones;
namespace ClasesAbstractas
{
    public abstract class Persona
    {
        public enum ENacionalidad
        {
            Argentino,
            Extranjero
        }
        private int dni;
        private string nombre;
        private string apellido;
        private ENacionalidad nacionalidad;

        public string Apellido
        {
            get
            {
                return this.apellido;
            }
            set
            {
                if (!(ValidarNombreApellido(value) is null))
                {
                    this.apellido = value;
                }
            }
        }
        public string Nombre
        {
            get
            {
                return this.nombre;
            }
            set
            {
                if (!(ValidarNombreApellido(value) is null))
                {
                    this.apellido = value;
                }
            }
        }
        public ENacionalidad Nacionalidad
        {
            get
            {
                return this.nacionalidad;
            }
            set
            {
                if (value == ENacionalidad.Argentino || value == ENacionalidad.Extranjero)
                {
                    this.nacionalidad = value;
                }
                else
                {
                    throw new NacionalidadInvalidaException();
                }
            }
        }
        public int DNI
        {
            get
            {
                return this.dni;
            }
            set
            {
                if ((ValidarDni(ENacionalidad.Argentino, value) != -1) || (ValidarDni(ENacionalidad.Extranjero, value) != -1))
                {
                    this.dni = value;
                }
            }
        }
        public string StringToDNI
        {
            set
            {
                int auxValue = ValidarDni(ENacionalidad.Argentino, value);
                if (auxValue != -1)
                {
                    this.dni = auxValue;
                }
            }
        }
        public Persona()
        {

        }
        public Persona(string nombre, string apellido, ENacionalidad nacionalidad)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.nacionalidad = nacionalidad;
        }
        public Persona(string nombre, string apellido, int dni, ENacionalidad nacionalidad)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.nacionalidad = nacionalidad;
            this.dni = dni;
        }
        public Persona(string nombre, string apellido, string dni, ENacionalidad nacionalidad)
        {
            this.nombre = nombre;
            this.apellido = apellido;
            this.nacionalidad = nacionalidad;
            this.StringToDNI = dni;/// revisar al terminar las clases.
        }
        ///
        public override string ToString()
        {//cambiar por propiedades------------------------------------------------
            StringBuilder retorno = new StringBuilder();
            retorno.AppendFormat("Nombre: {0,10}\n", this.nombre);
            retorno.AppendFormat("Apellido:{ 1,10}\n", this.apellido);
            retorno.AppendFormat("DNI:{ 3,10}\n", this.dni);
            retorno.AppendFormat("Nacionalidad:{ 2,10}\n", this.nacionalidad);
            return retorno.ToString();
        }
        /// 
        private int ValidarDni(ENacionalidad nacionalidad, int dato)
        {
            int retorno = -1;
            string auxDato = dato.ToString();
            try
            {
                retorno = ValidarDni(nacionalidad, auxDato);
            }
            catch (NacionalidadInvalidaException e)//----------------------------------------------
            {
                Console.WriteLine(e.Message);
            }
            catch (DniInvalidoException e)
            {
                Console.WriteLine(e.Message);
            }
            return retorno;

        }

        private int ValidarDni(ENacionalidad nacionalidad, string dato)
        {
            int retorno = -1;
            int auxDni;
            Regex soloNumeros = new Regex("^[0-9]+?$");
            try
            {
                if (soloNumeros.IsMatch(dato))//si el "Dato" es solo numeros continuar
                {
                    bool validacion = Int32.TryParse(dato, out auxDni);
                    if (validacion)
                    {
                        if ((nacionalidad == ENacionalidad.Argentino) && (auxDni > 0) && (auxDni <= 89999999))
                        {
                            retorno = auxDni;
                        }
                        else if ((nacionalidad == ENacionalidad.Extranjero) && (auxDni >= 90000000) && (auxDni <= 99999999))
                        {
                            retorno = auxDni;
                        }
                        else
                        {
                            throw new NacionalidadInvalidaException();
                        }
                    }
                    else
                    {
                        throw new DniInvalidoException();///----------------
                    }

                }
                else
                {
                    throw new DniInvalidoException();///----------------
                }

            }
            catch (NacionalidadInvalidaException)//-------------------------
            {

            }
            return retorno;
        }
        private string ValidarNombreApellido(string dato)
        {
            string retorno = null;
            Regex SoloLetras = new Regex("^[a-z|A-Z]+?$");
            if (SoloLetras.IsMatch(dato))
            {
                retorno = dato;
            }
            return retorno;
        }


    }
}
