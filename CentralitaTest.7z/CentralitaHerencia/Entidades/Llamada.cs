﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{

    public abstract class Llamada
    {
        protected float duracion;
        protected string nroDestino;
        protected string nroOrigen;
                
        public enum TipoLlamada
        {
            Local,
            Provincial,
            Todas
        }


        public float Duracion
        {
            get
            {
                return this.duracion;
            }
        }
        public string NroDestino
        {
            get
            {
                return this.nroDestino;
            }
        }
        public string NroOrigen
        {
            get
            {
                return this.nroOrigen;
            }
        }
        public abstract float CostoLlamada
        {
            get;
        }

        public Llamada(float duracion, string nroDestino, string nroOrigen)
        {
            this.duracion = duracion;
            this.nroOrigen = nroOrigen;
            this.nroDestino = nroDestino;
        }
        public static int OrdenarPorDuracion(Llamada llamadaUno, Llamada llamadaDos)
        {
            int retorno = -1;
            if (llamadaUno.Duracion > llamadaDos.duracion)
            {
                retorno = 1;
            }
            else if (llamadaUno.Duracion == llamadaDos.duracion)
            {
                retorno = 0;
            }
            return retorno;
        }

        protected virtual string Mostrar()
        {
            StringBuilder retorno = new StringBuilder();
            retorno.AppendLine("Numero de Origen: " + this.NroOrigen);
            retorno.AppendLine("Numero de Destino: " + this.NroDestino);
            retorno.AppendLine("Duracion de llamada: " + this.Duracion);
            retorno.AppendLine("--------------------------------------");
            return retorno.ToString();
        }        
        public static bool operator ==(Llamada llamadaUno, Llamada llamadaDos)//falta sobrecargar equals en las derivadas
        {
            bool retorno = false;
            if(llamadaDos.nroDestino == llamadaUno.nroDestino)//y verificar equals
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator !=(Llamada llamadaUno, Llamada llamadaDos)
        {
            bool retorno = false;
            if (! (llamadaDos == llamadaUno))
            {
                retorno = true;
            }
            return retorno;
        }


    }
}
