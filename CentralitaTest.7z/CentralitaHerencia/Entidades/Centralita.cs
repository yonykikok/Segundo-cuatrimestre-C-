using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
namespace Entidades
{
  public class Centralita
  {
    private List<Llamada> listaDeLlamadas;
    protected string razonSocial;
    public float GananciaPorLocal
    {
      get
      {
        return this.CalcularGanancia(Llamada.TipoLlamada.Local);
      }
    }
    public float GananciaPorProvincial
    {
      get
      {
        return this.CalcularGanancia(Llamada.TipoLlamada.Provincial);
      }
    }
    public float GananciaPorTotal
    {
      get
      {
        return this.CalcularGanancia(Llamada.TipoLlamada.Todas);
      }
    }
    public List<Llamada> Llamadas
    {
      get
      {
        return this.listaDeLlamadas;
      }
    }
    private void AgregarLlamada(Llamada nuevaLlamada)
    {
      this.listaDeLlamadas.Add(nuevaLlamada);
    }
    private float CalcularGanancia(Llamada.TipoLlamada tipo)
    {
      float GananciaLocal = 0;
      float GananciaProvincial = 0;
      float GananciaTotal = 0;
      foreach (Llamada llamada in Llamadas)
      {
        if (llamada is Local && tipo == Local.TipoLlamada.Local)
        {
          Local aux = (Local)llamada;
          GananciaLocal += aux.CostoLlamada;
          GananciaTotal += aux.CostoLlamada;
        }
        if (llamada is Provincial && tipo == Provincial.TipoLlamada.Provincial)
        {
          Provincial aux = (Provincial)llamada;
          GananciaProvincial += aux.CostoLlamada;
          GananciaTotal += aux.CostoLlamada;
        }
      }
      if (tipo == Local.TipoLlamada.Local)
      {
        return GananciaLocal;
      }
      else if (tipo == Provincial.TipoLlamada.Provincial)
      {
        return GananciaProvincial;
      }
      else
      {
        return GananciaTotal;
      }
    }

    public Centralita()
    {
      this.listaDeLlamadas = new List<Llamada>();
    }
    public Centralita(string nombreDeEmpresa) : this()
    {
      this.razonSocial = nombreDeEmpresa;
    }
    public string Mostrar(Llamada.TipoLlamada tipo)
    {
      StringBuilder retorno = new StringBuilder();
      retorno.AppendLine("Razon Social: " + this.razonSocial);
      retorno.AppendLine("Ganancia Local: " + GananciaPorLocal);
      retorno.AppendLine("Ganancia Provincial: " + GananciaPorProvincial);
      retorno.AppendLine("Ganancia Total: " + GananciaPorTotal);
      foreach (Llamada llamada in Llamadas)
      {
        switch (tipo)
        {
          case Llamada.TipoLlamada.Local:
            if (llamada is Local)
            {
              retorno.Append(llamada.ToString());
              retorno.AppendLine("--------------------------------------");
            }
            break;
          case Llamada.TipoLlamada.Provincial:
            if (llamada is Provincial)
            {
              retorno.Append(llamada.ToString());
              retorno.AppendLine("--------------------------------------");
            }
            break;
          default:
            retorno.Append(llamada.ToString());
            retorno.AppendLine("--------------------------------------");

            break;

        }

      }
      return retorno.ToString();
    }
    public string Mostrar()
    {
      StringBuilder retorno = new StringBuilder();
      retorno.AppendLine("Razon Social: " + this.razonSocial);
      retorno.AppendLine("Ganancia Local: " + GananciaPorLocal);
      retorno.AppendLine("Ganancia Provincial: " + GananciaPorProvincial);
      retorno.AppendLine("Ganancia Total: " + GananciaPorTotal);
      foreach (Llamada llamada in Llamadas)
      {
        retorno.Append(llamada.ToString());
        retorno.AppendLine("--------------------------------------");
      }
      return retorno.ToString();
    }

    public static bool operator ==(Centralita centralita, Llamada llamada)
    {
      bool retorno = false;
      if (!object.ReferenceEquals(centralita, null) && !object.ReferenceEquals(llamada, null))
      {
        foreach (Llamada auxLlamada in centralita.Llamadas)
        {
          if (auxLlamada == llamada)
          {
            retorno = true;
            break;
          }
        }
      }
      return retorno;
    }
    public static bool operator !=(Centralita centralita, Llamada llamada)
    {
      bool retorno = false;
      if (!object.ReferenceEquals(centralita, null) && !object.ReferenceEquals(llamada, null))
      {
        if (!(centralita == llamada))
        {
          retorno = true;
        }
      }
      return retorno;
    }

    public static Centralita operator +(Centralita centralita, Llamada nuevaLlamada)
    {

      if (centralita != nuevaLlamada)
      {
        centralita.AgregarLlamada(nuevaLlamada);
      }
      else
      {
        throw new CentralitaException("ERROR, esta llamada ya se encuentra en la lista", "Centralita", " operador + sobrecargado");
      }
      return centralita;
    }
    public override string ToString()
    {
      return this.Mostrar();
    }
    public void OrdenarLlamadas()
    {
      Llamadas.Sort(Llamada.OrdenarPorDuracion);
    }
  }
}
