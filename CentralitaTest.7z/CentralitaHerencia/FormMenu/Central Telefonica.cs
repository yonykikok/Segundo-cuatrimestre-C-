using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
namespace FormMenu
{
  public partial class Central : Form
  {
    public Centralita miCentral;
    public Central()
    {
      InitializeComponent();
    }

    private void Central_Load(object sender, EventArgs e)
    {

    }
    //Generar llamada
    private void button1_Click(object sender, EventArgs e)
    {
      miCentral = new Centralita("mutltitask");
      FrmLlamador llamador = new FrmLlamador(miCentral);
      llamador.ShowDialog();
    }
    //Facturar Todas
    private void button2_Click(object sender, EventArgs e)
    {
      FrmMostrar mostrar = new FrmMostrar(miCentral);
      mostrar.SetLlamada = Llamada.TipoLlamada.Todas;
      
      mostrar.ShowDialog();
    }

    private void buttonFacturacionLocal_Click(object sender, EventArgs e)
    {
      FrmMostrar mostrar = new FrmMostrar(miCentral);
      mostrar.SetLlamada = Llamada.TipoLlamada.Local;

      mostrar.ShowDialog();
    }

    private void buttonFacturacionProvincial_Click(object sender, EventArgs e)
    {
      FrmMostrar mostrar = new FrmMostrar(miCentral);
      mostrar.SetLlamada = Llamada.TipoLlamada.Provincial;

      mostrar.ShowDialog();
    }

    private void buttonSalir_Click(object sender, EventArgs e)
    {
      Close();
    }
  }
}
