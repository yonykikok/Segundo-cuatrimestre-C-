using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
namespace FormMenu
{
  public partial class FrmLlamador : Form
  {
    protected Centralita miCentral;

    public FrmLlamador(Centralita central)
    {
      InitializeComponent();
      miCentral = central;
    }


    public Centralita GetCentralita
    {
      get
      {
        return miCentral;///nose que devolver 
      }
    }

    private void FrmLlamador_Load(object sender, EventArgs e)
    {
      textBoxNroDestino.Text = "";
      comboBoxFranja.DataSource = Enum.GetValues(typeof(Entidades.Franja));
    }

    private void textBox1_TextChanged(object sender, EventArgs e)
    {

    }

    private void textBox2_TextChanged(object sender, EventArgs e)
    {

    }

    private void button4_Click(object sender, EventArgs e)
    {
      string aux = textBoxNroDestino.Text;
      textBoxNroDestino.Text += "1";
    }

    private void button2_Click(object sender, EventArgs e)
    {
      string aux = textBoxNroDestino.Text;
      textBoxNroDestino.Text += "2";
    }

    private void button3_Click(object sender, EventArgs e)
    {
      string aux = textBoxNroDestino.Text;
      textBoxNroDestino.Text += "3";
    }

    private void button4_Click_1(object sender, EventArgs e)
    {
      string aux = textBoxNroDestino.Text;
      textBoxNroDestino.Text += "4";
    }

    private void button5_Click(object sender, EventArgs e)
    {
      string aux = textBoxNroDestino.Text;
      textBoxNroDestino.Text += "5";
    }

    private void button6_Click(object sender, EventArgs e)
    {
      string aux = textBoxNroDestino.Text;
      textBoxNroDestino.Text += "6";
    }

    private void button7_Click(object sender, EventArgs e)
    {
      string aux = textBoxNroDestino.Text;
      textBoxNroDestino.Text += "7";
    }

    private void button8_Click(object sender, EventArgs e)
    {
      string aux = textBoxNroDestino.Text;
      textBoxNroDestino.Text += "8";
    }

    private void button9_Click(object sender, EventArgs e)
    {
      string aux = textBoxNroDestino.Text;
      textBoxNroDestino.Text += "9";
    }

    private void button0_Click(object sender, EventArgs e)
    {
      string aux = textBoxNroDestino.Text;
      textBoxNroDestino.Text += "0";
    }

    private void buttonAsterisco_Click(object sender, EventArgs e)
    {
      string aux = textBoxNroDestino.Text;
      textBoxNroDestino.Text += "*";
    }

    private void buttonNumeral_Click(object sender, EventArgs e)
    {
      string aux = textBoxNroDestino.Text;
      textBoxNroDestino.Text += "#";
    }

    private void buttonLimpiar_Click(object sender, EventArgs e)
    {
      textBoxNroDestino.Text = "";
    }

    private void buttonLlamar_Click(object sender, EventArgs e)
    {
      string numeroDestino = textBoxNroDestino.Text;
      Random random = new Random();
      float costo = random.Next(0, 5);
      int duracion = random.Next(1, 50);

      if (!numeroDestino.StartsWith("#"))
      {
        comboBoxFranja.Enabled = false;
        Local llamadaLocal = new Local(textBoxNroOrigen.Text, duracion, numeroDestino, costo);
        try
        {
          miCentral += llamadaLocal;
        }
        catch(CentralitaException exception)
        {
          MessageBox.Show(exception.Message);
        }
        }
      else
      {
        Franja franjas;
        Enum.TryParse<Franja>(comboBoxFranja.SelectedValue.ToString(), out franjas);
        Provincial llamadaProvincial = new Provincial(textBoxNroOrigen.Text, franjas, duracion, numeroDestino);
        miCentral += llamadaProvincial;
      }
      textBoxNroDestino.Text = "";

    }
  }
}
