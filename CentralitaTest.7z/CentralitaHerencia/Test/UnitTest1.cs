using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;
using System.Collections.Generic;

namespace Test
{
  [TestClass]
  public class UnitTest1
  {
    [TestMethod]
    public void TestInstanciada()
    {
      Centralita centralita = new Centralita();
      Assert.IsNotNull(centralita.Llamadas);
    }
    [TestMethod]
    public void TestAgregarMismaLlamada()
    {
      Centralita centralita = new Centralita();
      Local llamadaUno = new Local("5454554", 23, "1540132154", 234);
      Local llamadaDos = new Local("5454554", 4543, "1540132154", 95);
      Provincial llamadaTres = new Provincial("1562956598", Franja.Franja_1, 45, "1538941181");
      Provincial llamadaCuatro = new Provincial("1562956598", Franja.Franja_2, 23, "1538941181");
      try
      {
        centralita += llamadaUno;
        centralita += llamadaDos;
        centralita += llamadaTres;
        centralita += llamadaCuatro;
        Assert.Fail();
      }
      catch (CentralitaException e)
      {

      }
    }
  }
}
