using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades
{
  public class Dao :IArchivo<Votacion>
  {
    string strConnection = "Data Source=LAB3PC05\\SQLEXPRESS; Initial Catalog = votacion-sp-2018;Integrated Security= true";
    SqlConnection conexion = null;
    SqlCommand comando = null;
    string consulta = null;
    public bool Guardar(string rutaArchivo, Votacion objeto)
    {
      conexion = new SqlConnection(strConnection);
      conexion.ConnectionString = strConnection;
      consulta= "UPDATE Votaciones SET nombreLey WHERE id =  "
      comando.ExecuteNonQuery();


    }

    public Votacion Leer(string rutaArchivo)
    {
      throw new NotImplementedException();
    }
  }
}
