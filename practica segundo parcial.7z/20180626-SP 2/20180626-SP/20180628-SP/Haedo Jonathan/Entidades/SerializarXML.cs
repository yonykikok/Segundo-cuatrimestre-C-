using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using System.Xml.Serialization;
using Exceptiones;
namespace Entidades
{
  public class SerializarXML : IArchivo<Votacion>
  {
    public bool Guardar(string rutaArchivo, Votacion objeto)
    {
      bool retorno = false;
      XmlTextWriter writer = null;
      XmlSerializer serializador = null;
      try
      {
        writer = new XmlTextWriter(rutaArchivo,Encoding.UTF8);
        serializador = new XmlSerializer(typeof(Votacion));
        serializador.Serialize(writer, objeto);
        retorno = true;
      }
      catch (Exception exception)
      {
        throw new ErrorArchivoException("Error al serializar el objeto");
      }
      finally
      {
        if (!(writer is null))
          writer.Close();
      }
      return retorno;
    }

    public Votacion Leer(string rutaArchivo)
    {
      Votacion retorno = null;
      XmlTextReader reader = null;
      XmlSerializer serializador = null;
      try
      {
        reader = new XmlTextReader(rutaArchivo);
        serializador = new XmlSerializer(typeof(Votacion));
        retorno = (Votacion)serializador.Deserialize(reader);
      }
      catch (Exception exception)
      {

        throw new ErrorArchivoException("Error al Leer el archivo");
      }
      finally
      {
        reader.Close();
      }
      return retorno;
    }

  }
}
