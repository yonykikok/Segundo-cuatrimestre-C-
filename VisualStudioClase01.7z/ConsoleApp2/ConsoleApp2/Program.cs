﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title="Ejercicio Nº2";
            int numero;
            double cuadrado;
            double cubo;

            numero = Convert.ToInt32(Console.ReadLine());
            cuadrado=Math.Pow(numero, 2);
            cubo=Math.Pow(numero, 3);
            if (numero>0)
            {
                Console.WriteLine("el cuadrado del numero " + numero + " es " + cuadrado + " y el cubo es " + cubo);
            }
            else
            {
                Console.WriteLine("ERROR. ¡Reingresar número!");
            }
            Console.ReadLine();
        }
    }
}
