﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp3
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero;
            int i;
            int calculo;
            numero=Convert.ToInt32(Console.ReadLine());

            for(i=1;i<numero+1;i++)
            {
                calculo = numero%i;
                if(calculo!=0)
                {
                    if(calculo%numero==0)
                    {
                        Console.WriteLine(calculo);

                    }
                }
                
            }
            Console.ReadKey();
            
        }
    }
}
