﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Ejercicio Nº1";
            //Console.ReadKey();
            int i;
            int max;
            int min;
            int promedio;
            int suma=0;
            int[] numero=new int[5];

                for(i=0;i<5;i++)
                {
                    numero[i]=Convert.ToInt32(Console.ReadLine());
                    suma = suma + numero[i];
                }
                max = numero[0];
                min = numero[0];

                for (i=0;i<5;i++)
                {
                    if (numero[i] > max)
                    {
                        max = numero[i];
                    }
                    else if (numero[i]<min)
                    {
                        min = numero[i];
                    }                
                }
                promedio=suma/5;
            Console.WriteLine("maximo: " + max + "\nminimo: " + min + "\nSuma Total: " + suma+"\npromedio: "+promedio);

            Console.ReadKey();
        }
    }
}
