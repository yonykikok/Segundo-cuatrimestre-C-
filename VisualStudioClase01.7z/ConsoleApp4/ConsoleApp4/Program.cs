﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp4
{
    class Program
    {
        static void Main(string[] args)
        {
            int numero=1;
            int i;
            int contador = 0;
            int suma=0;
            do
            {
                for(i=1;i<numero;i++)
                {
                    if (numero % i == 0)
                    {
                        suma += i;                   
                    }   
                }
                if (numero == suma)
                {
                    Console.WriteLine(suma);
                    contador++;
                }
                suma = 0;
                numero++;

            } while (contador<5);
            Console.ReadKey();
        }
    }
}
