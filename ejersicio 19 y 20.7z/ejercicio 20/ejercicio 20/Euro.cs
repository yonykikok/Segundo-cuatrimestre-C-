﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_20
{
    class Euro
    {
        private double cantidad;
        private static float cotizRespectoDolar;
        public Euro(double inCantidad) : this()
        {
            this.cantidad = inCantidad;
        }
        public Euro(double inCantidad, float inCotizacion) : this(inCantidad)
        {
            Euro.cotizRespectoDolar = inCotizacion;
        }

        private Euro()
        {
            Euro.cotizRespectoDolar = (float)1.3642;
        }
        public static float GetCotizacion()
        {
            return Euro.cotizRespectoDolar;
        }
    }
}
