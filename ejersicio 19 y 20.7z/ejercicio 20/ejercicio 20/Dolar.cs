﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_20
{
    class Dolar
    {
        private double cantidad;
        private static float cotizRespectoDolar;

        public Dolar(double inCantidad) : this()
        {
            this.cantidad = inCantidad;
        }
        public Dolar(double inCantidad, float inCotizacion) : this(inCantidad)
        {
            Dolar.cotizRespectoDolar = inCotizacion;
        }

        private Dolar()
        {
            Dolar.cotizRespectoDolar = 1;
        }

        public static float GetCotizacion()
        {
            return Dolar.cotizRespectoDolar;
        }
        public static explicit operator Euro(Dolar dolar)
        {
            Euro retorno = new Euro(dolar.cantidad * Euro.GetCotizacion());

            return retorno;
        }
        public static explicit operator Pesos(Dolar dolar)
        {
            Pesos retorno = new Pesos(dolar.cantidad * Pesos.GetCotizacion());
            return retorno;
        }



    }
}
