﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_20
{
    class Pesos
    {
        private double cantidad;
        private static float cotizRespectoDolar;
        public Pesos(double inCantidad) : this()
        {
            this.cantidad = inCantidad;
        }
        public Pesos(double inCantidad, float inCotizacion) : this(inCantidad)
        {
            Pesos.cotizRespectoDolar = inCotizacion;
        }

        private Pesos()
        {
            Pesos.cotizRespectoDolar = (float)17.55;
        }
        public static float GetCotizacion()
        {
            return Pesos.cotizRespectoDolar;
        }
    }
}
