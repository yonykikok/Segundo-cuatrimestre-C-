﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_19
{
    class Sumador
    {
        private int cantidadSumas;
        
        public Sumador(int valor)
        {
            this.cantidadSumas = valor;
        }
        public Sumador() : this(0)
        {

        }
        public long Sumar(long num1, long num2)
        {
            long retorno;
                retorno = num1 + num2;
            return retorno;
        }
        public string Sumar(string cadena1, string cadena2)
        {
            StringBuilder retorno = new StringBuilder();

            retorno.Append(cadena1);
            retorno.Append(cadena2);

            return retorno.ToString();
        }
        public static explicit operator int( Sumador objetoSumador)
        {
            return objetoSumador.cantidadSumas;
        }
        public static long operator +(Sumador uno, Sumador dos)
        {            
            return (long) uno.cantidadSumas + dos.cantidadSumas;
        }
        public static bool operator |(Sumador uno, Sumador dos)
        {
            bool retorno = false;
            if(uno.cantidadSumas==dos.cantidadSumas)
            {
                retorno=true;
            }

            return retorno;
        }
    }
}
