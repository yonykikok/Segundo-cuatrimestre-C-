﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ejercicio_19
{
    class Program
    {
        static void Main(string[] args)
        {
            Sumador objetoTest = new Sumador(25);
            Sumador objetoTest2 = new Sumador(25);

            objetoTest.Sumar(4, 5);
            objetoTest2.Sumar(4, 5);
            if(objetoTest|objetoTest2)
            {
                Console.WriteLine("son iguales las cantidades");
            }
           
                Console.WriteLine("se sumo {0}",(objetoTest+objetoTest2));
            Console.ReadKey();

        }
    }
}
