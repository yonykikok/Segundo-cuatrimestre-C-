﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ejercicio_28
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonCalcular_Click(object sender, EventArgs e)
        {

            Dictionary<String, int> myDictionary = new Dictionary<string, int>();
            List<string> myList;
            myList = richTextBox.Text.Split(' ').ToList();

            foreach (string palabra in myList)
            {
                if (!(myDictionary.ContainsKey(palabra)))//si "palabra " no esta en el diccionario
                {
                    myDictionary.Add(palabra, 1);
                }
                else if (myDictionary.ContainsKey(palabra))//si encuentra la palabra en el diccionario
                {
                    myDictionary[palabra]++;
                }
            }
            int mayor = 0;
            int intermedio = 0;
            int menor = 0;
            Dictionary<string, int> myDictionary2 = new Dictionary<string, int>();
            foreach (KeyValuePair<string, int> parClaveValor in myDictionary)
            {
                if (mayor < parClaveValor.Value)
                {
                    mayor = parClaveValor.Value;
                    if (!myDictionary2.ContainsKey(parClaveValor.Key))
                    {
                        myDictionary2.Add(parClaveValor.Key, parClaveValor.Value);
                    }
                }
                else if (intermedio < parClaveValor.Value && intermedio < mayor)
                {
                    intermedio = parClaveValor.Value;
                    if (!myDictionary2.ContainsKey(parClaveValor.Key))
                    {
                        myDictionary2.Add(parClaveValor.Key, parClaveValor.Value);
                    }
                }
                else if (menor < parClaveValor.Value && menor < intermedio)
                {
                    menor = parClaveValor.Value;
                    if (!myDictionary2.ContainsKey(parClaveValor.Key))
                    {
                        myDictionary2.Add(parClaveValor.Key, parClaveValor.Value);
                    }
                }
            }

            MessageBox.Show(Convert.ToString(mayor));
            MessageBox.Show(Convert.ToString(intermedio));
            MessageBox.Show(Convert.ToString(menor));

            foreach(KeyValuePair<string,int> parClaveValor in myDictionary2)
            {
                MessageBox.Show(parClaveValor.Key);
            }

        }
    }
}
