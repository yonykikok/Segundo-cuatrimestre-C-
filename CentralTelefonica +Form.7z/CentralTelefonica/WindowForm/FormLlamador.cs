﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using CentralitaHerencia;
namespace FormLlamador
{
    public partial class FormLlamador : Form
    {
        private Centralita miCentralita;
        public FormLlamador(Centralita centralita)
        {
            this.miCentralita = centralita;
            InitializeComponent();
        }

        private void FormLlamador_Load(object sender, EventArgs e)
        {

        }
    }
}
