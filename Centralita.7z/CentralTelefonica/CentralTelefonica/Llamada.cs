﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CentralitaHerencia
{
    public class Llamada
    {
        protected string nroDestino;
        protected string nroOrigen;
        protected float duracion;

        public float Duracion
        {
            get
            {
                return this.duracion;
            }
        }
        public string NroOrigen
        {
            get
            {
                return this.nroOrigen;
            }
        }
        public string NroDestino
        {
            get
            {
                return this.nroDestino;
            }
        }
    }
}
