﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_31
{
    public class Negocio
    {
        private PuestoAtencion caja;
        private Queue<Cliente> clientes;
        private string nombre;

        public Cliente Cliente
        {
            get
            {
                return this.clientes.Dequeue();// saca al cliente de la cola.
            }
            set
            {
                if (!(this.clientes.Contains(value)))
                {
                    this.clientes.Enqueue(value);
                }

            }

        }
        private Negocio()
        {
            this.clientes = new Queue<Cliente>();
            //this.caja= PuestoAtencion.Puesto.Caja1; 

        }
        public Negocio(string name)
        {
            this.nombre = name;
        }

        public static bool operator +(Negocio negocio, Cliente cliente)
        {
            bool retorno = false;
            if((negocio==cliente)==true)
            {
                retorno = true;
            }
            return retorno;
        }
        public static bool operator ~(Negocio negocio)
        {
            bool retorno=false;
            if(negocio.caja.Atender(negocio.Cliente)==true)
            {
                retorno= true;
            }
            return retorno;
        }
        public static bool operator ==(Negocio negocio, Cliente cliente)
        {
            bool retorno = false;
            if (negocio.clientes.Contains(cliente))
            {
                retorno= true;
            }
            return retorno;
        }
        public static bool operator !=(Negocio negocio, Cliente cliente)
        {
            bool retorno = false;
           if (!(negocio==cliente))
            {
                retorno = true;
            }
            return retorno;
        }

    }
}

