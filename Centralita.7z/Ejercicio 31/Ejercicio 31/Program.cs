﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_31
{
    class Program
    {
        static void Main(string[] args)
        {
            Cliente miCliente = new Cliente(2, "Juan");
            Cliente miCliente2 = new Cliente(3, "Pablo");
            Cliente miCliente3 = new Cliente(3, "Pablo");
            Negocio miNegocio = new Negocio("Multitask");
            Negocio miNegocio2 = new Negocio("Multitask 2");    
            if(miCliente3==miCliente2)
            {
                Console.WriteLine("es el mismo cliente");
            }
            else if (miCliente3!=miCliente2)
            {
                Console.WriteLine("Son distintos clientes");
            }



            Console.ReadKey();
            PuestoAtencion miPuestoDeAtencion = new PuestoAtencion(PuestoAtencion.Puesto.Caja1);

        }
    }
}
