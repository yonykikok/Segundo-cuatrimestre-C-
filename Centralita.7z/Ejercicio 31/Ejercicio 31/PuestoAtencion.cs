﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
namespace Ejercicio_31
{
    public class PuestoAtencion
    {
        private int numeroActual;
        public enum Puesto
        {
            Caja1,
            Caja2

        }
        public int NumeroActual
        {
            get
            {
                this.numeroActual++;
                return this.numeroActual;
            }
        }

        public bool Atender (Cliente cliente)
        {
            Thread.Sleep(3000);
            return true;
        }
        private PuestoAtencion()
        {
            this.numeroActual = 0;
        }
        public PuestoAtencion(Puesto puesto)
        {
                
        }
    }

}

