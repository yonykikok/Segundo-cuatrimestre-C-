﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_34_Herencias
{
    public class VehiculoTerrestre
    {
        public enum Colores
        {
            red,
            blue,
            white,
            black,
            grey
        }
        public short cantidadRuedas;
        public short cantidadPuertas;
        public Colores color;

        public VehiculoTerrestre(short cantRudas, short cantPuertas, Colores color)
        {           
            this.cantidadPuertas = cantPuertas;
            this.cantidadRuedas = cantRudas;
            this.color = color;
        }

    }
}
