﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_34_Herencias
{
    public class Moto:VehiculoTerrestre
    {
        public short cilindrada;
        public Moto(short cilindrada, Colores color, short cantPuertas, short cantRuedas) : base(cantRuedas, cantPuertas, color)
        {
            this.cilindrada = cilindrada;
        }       
    }
    
}
