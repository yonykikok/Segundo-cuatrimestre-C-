﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_34_Herencias
{
    public class Automovil:VehiculoTerrestre
    {
        public int cantidadPasajeros;
        public short cantidadMarchas;

        public Automovil(int cantPasajeros,short cantMarchas, Colores color, short cantPuertas, short cantRuedas) : base(cantRuedas, cantPuertas, color)
        {
            this.cantidadPasajeros = cantPasajeros;
            this.cantidadMarchas = cantMarchas;
        }
    }
}
