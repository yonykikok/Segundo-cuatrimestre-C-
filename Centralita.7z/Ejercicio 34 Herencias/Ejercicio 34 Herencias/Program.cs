﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_34_Herencias
{
    class Program
    {
        static void Main(string[] args)
        {
            Camion miCamion = new Camion(2, 2000, 6, VehiculoTerrestre.Colores.white, 2, 8);
            Moto miMoto = new Moto(250, VehiculoTerrestre.Colores.blue, 0, 2);
            Automovil miAuto = new Automovil(5, 6, VehiculoTerrestre.Colores.black, 5, 4);

            Console.WriteLine("Descripcion Moto: Cilindrada: {0}",miMoto.cilindrada);
            Console.WriteLine("Color: {0}", miMoto.color);
            Console.WriteLine("Cantidad de Puertas: {0}", miMoto.cantidadPuertas);
            Console.WriteLine("Cantidad de ruedas: {0}", miMoto.cantidadRuedas);

            Console.ReadKey();
        }
    }
}
