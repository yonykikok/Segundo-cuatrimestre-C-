﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Ejercicio_34_Herencias
{
    public class Camion : VehiculoTerrestre
    {
        public int cantidadPasajeros;
        public int pesoCarga;
        public short cantidadtMarchas;
        public Camion(int cantPasajeros, int pesoCarga, short cantMarchas, Colores color, short cantPuertas, short cantRuedas) : base(cantRuedas, cantPuertas, color)
        {
            this.cantidadPasajeros = cantPasajeros;
            this.pesoCarga = pesoCarga;
            this.cantidadtMarchas = cantMarchas;
        }        

    }
}
